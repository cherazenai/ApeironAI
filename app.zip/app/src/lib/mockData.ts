import type { 
  ResearchQuery, 
  Hypothesis, 
  Paper, 
  Simulation, 
  Experiment, 
  Project,
  DashboardAnalytics,
  AdminAnalytics,
  PricingPlan,
  Feature,
  UseCase,
  ChatMessage
} from '@/types';

export const mockDashboardAnalytics: DashboardAnalytics = {
  totalQueries: 248,
  totalHypotheses: 42,
  totalPapers: 156,
  totalSimulations: 89,
  queriesThisWeek: 35,
  hypothesesThisWeek: 8,
};

export const mockAdminAnalytics: AdminAnalytics = {
  totalUsers: 1248,
  activeUsers: 892,
  totalQueries: 45678,
  totalHypotheses: 8234,
  queriesToday: 342,
  newUsersThisWeek: 156,
  systemHealth: {
    status: 'healthy',
    uptime: 99.98,
    latency: 124,
  },
};

export const mockQueries: ResearchQuery[] = [
  {
    id: '1',
    userId: '1',
    query: 'Find catalysts for hydrogen production',
    response: 'Based on recent research, effective catalysts for hydrogen production include:\n\n1. Platinum-based catalysts - highest efficiency\n2. Nickel-molybdenum alloys - cost-effective alternative\n3. Cobalt phosphide nanoparticles - emerging technology\n\nKey papers support the use of transition metal phosphides for improved catalytic activity.',
    timestamp: new Date(Date.now() - 86400000),
    category: 'Chemistry',
  },
  {
    id: '2',
    userId: '1',
    query: 'Suggest new battery chemistry to improve energy density',
    response: 'Several promising battery chemistries for improved energy density:\n\n1. Solid-state lithium-metal batteries\n2. Lithium-sulfur batteries\n3. Silicon nanowire anodes\n4. High-nickel NMC cathodes\n\nResearch indicates solid-state designs can achieve 400+ Wh/kg.',
    timestamp: new Date(Date.now() - 172800000),
    category: 'Energy',
  },
  {
    id: '3',
    userId: '1',
    query: 'Carbon capture materials for industrial applications',
    response: 'Leading carbon capture materials include:\n\n1. Metal-organic frameworks (MOFs)\n2. Amine-functionalized adsorbents\n3. Calcium looping materials\n4. Zeolite-based systems\n\nMOFs show highest CO2 selectivity at low concentrations.',
    timestamp: new Date(Date.now() - 259200000),
    category: 'Climate',
  },
];

export const mockHypotheses: Hypothesis[] = [
  {
    id: '1',
    userId: '1',
    topic: 'Perovskite Solar Cells',
    hypothesis: 'Adding a thin layer of graphene oxide between the perovskite and transport layer will improve charge extraction efficiency by 15% and reduce hysteresis.',
    confidenceScore: 78,
    supportingPapers: [
      {
        id: 'p1',
        userId: '1',
        title: 'Graphene Oxide Interface Engineering in Perovskite Solar Cells',
        authors: ['Zhang, L.', 'Kumar, R.'],
        abstract: 'Interface engineering using graphene oxide...',
        tags: ['perovskite', 'graphene', 'solar'],
        uploadedAt: new Date(),
      },
    ],
    generatedAt: new Date(Date.now() - 604800000),
  },
  {
    id: '2',
    userId: '1',
    topic: 'Drug Discovery',
    hypothesis: 'The compound XYZ-784 will show 3x higher binding affinity to the ACE2 receptor compared to current treatments, based on molecular docking simulations.',
    confidenceScore: 65,
    supportingPapers: [],
    generatedAt: new Date(Date.now() - 1209600000),
  },
  {
    id: '3',
    userId: '1',
    topic: 'Battery Materials',
    hypothesis: 'Silicon-carbon composite anodes with 20% silicon content will achieve 3000 cycles at 80% capacity retention.',
    confidenceScore: 82,
    supportingPapers: [],
    generatedAt: new Date(Date.now() - 1814400000),
  },
];

export const mockPapers: Paper[] = [
  {
    id: '1',
    userId: '1',
    title: 'Advanced Materials for Next-Generation Batteries',
    authors: ['Chen, W.', 'Johnson, M.', 'Lee, S.'],
    abstract: 'This review covers recent advances in battery materials including solid-state electrolytes, silicon anodes, and high-voltage cathodes...',
    summary: 'Comprehensive review of battery materials with focus on silicon anodes and solid-state designs.',
    tags: ['battery', 'materials', 'energy storage'],
    uploadedAt: new Date(Date.now() - 259200000),
  },
  {
    id: '2',
    userId: '1',
    title: 'Machine Learning for Drug Discovery: A Review',
    authors: ['Smith, A.', 'Brown, K.'],
    abstract: 'Machine learning approaches are transforming drug discovery by enabling rapid screening of molecular libraries...',
    summary: 'Overview of ML techniques in drug discovery including deep learning models for molecular property prediction.',
    tags: ['machine learning', 'drug discovery', 'AI'],
    uploadedAt: new Date(Date.now() - 518400000),
  },
  {
    id: '3',
    userId: '1',
    title: 'Catalytic Hydrogen Production from Water Splitting',
    authors: ['Garcia, R.', 'Wang, L.'],
    abstract: 'Photocatalytic water splitting using semiconductor materials offers a sustainable route to hydrogen production...',
    summary: 'Review of photocatalytic water splitting mechanisms and catalyst design principles.',
    tags: ['catalysis', 'hydrogen', 'water splitting'],
    uploadedAt: new Date(Date.now() - 777600000),
  },
  {
    id: '4',
    userId: '1',
    title: 'Carbon Capture Using Metal-Organic Frameworks',
    authors: ['Anderson, P.', 'Zhang, Y.'],
    abstract: 'MOFs with high surface area and tunable pore chemistry show exceptional CO2 capture capacity...',
    summary: 'Analysis of MOF structures for selective CO2 capture from flue gas streams.',
    tags: ['carbon capture', 'MOF', 'climate'],
    uploadedAt: new Date(Date.now() - 1036800000),
  },
];

export const mockSimulations: Simulation[] = [
  {
    id: '1',
    userId: '1',
    name: 'Li-ion Battery Degradation',
    type: 'material',
    parameters: { temperature: 25, cycles: 1000, cRate: 1 },
    results: { capacityRetention: 85, impedanceGrowth: 15 },
    status: 'completed',
    createdAt: new Date(Date.now() - 604800000),
    completedAt: new Date(Date.now() - 604800000 + 3600000),
  },
  {
    id: '2',
    userId: '1',
    name: 'Catalyst Activity Prediction',
    type: 'reaction',
    parameters: { catalyst: 'Pt-Ni', temperature: 300, pressure: 1 },
    results: { activity: 0.85, selectivity: 0.92 },
    status: 'completed',
    createdAt: new Date(Date.now() - 432000000),
    completedAt: new Date(Date.now() - 432000000 + 1800000),
  },
  {
    id: '3',
    userId: '1',
    name: 'Drug-Protein Binding',
    type: 'experiment',
    parameters: { drugId: 'XYZ-784', protein: 'ACE2', method: 'docking' },
    status: 'running',
    createdAt: new Date(Date.now() - 3600000),
  },
];

export const mockExperiments: Experiment[] = [
  {
    id: '1',
    userId: '1',
    hypothesisId: '1',
    title: 'Graphene Oxide Interface Layer Testing',
    description: 'Test the effect of graphene oxide interlayer on perovskite solar cell performance.',
    steps: [
      { id: 's1', order: 1, description: 'Prepare perovskite precursor solution', completed: true },
      { id: 's2', order: 2, description: 'Deposit graphene oxide layer via spin coating', completed: true },
      { id: 's3', order: 3, description: 'Fabricate complete device stack', completed: false },
      { id: 's4', order: 4, description: 'Measure J-V characteristics', completed: false },
      { id: 's5', order: 5, description: 'Analyze hysteresis behavior', completed: false },
    ],
    status: 'in-progress',
    createdAt: new Date(Date.now() - 1209600000),
  },
  {
    id: '2',
    userId: '1',
    title: 'Silicon Anode Cycling Test',
    description: 'Evaluate cycling stability of Si-C composite anode.',
    steps: [
      { id: 's1', order: 1, description: 'Prepare Si-C composite electrode', completed: true },
      { id: 's2', order: 2, description: 'Assemble coin cells', completed: true },
      { id: 's3', order: 3, description: 'Conduct galvanostatic cycling', completed: true },
      { id: 's4', order: 4, description: 'Analyze capacity fade', completed: false },
    ],
    status: 'in-progress',
    createdAt: new Date(Date.now() - 1814400000),
  },
];

export const mockProjects: Project[] = [
  {
    id: '1',
    userId: '1',
    name: 'Next-Gen Solar Cells',
    description: 'Research project on perovskite and tandem solar cell architectures.',
    hypotheses: ['1'],
    papers: ['1'],
    simulations: ['1'],
    experiments: ['1'],
    createdAt: new Date(Date.now() - 2592000000),
    updatedAt: new Date(Date.now() - 604800000),
  },
  {
    id: '2',
    userId: '1',
    name: 'Battery Materials Research',
    description: 'Investigation of advanced anode and cathode materials.',
    hypotheses: ['3'],
    papers: ['1'],
    simulations: ['1'],
    experiments: ['2'],
    createdAt: new Date(Date.now() - 3456000000),
    updatedAt: new Date(Date.now() - 1209600000),
  },
];

export const pricingPlans: PricingPlan[] = [
  {
    id: 'starter',
    name: 'Starter',
    price: 0,
    period: 'month',
    description: 'Perfect for individual researchers getting started.',
    features: [
      'Paper summarization',
      'Research copilot',
      '5 queries per day',
      'Basic hypothesis generation',
      'Community support',
    ],
    cta: 'Get Started Free',
  },
  {
    id: 'researcher',
    name: 'Researcher',
    price: 29,
    period: 'month',
    description: 'For serious researchers who need full capabilities.',
    features: [
      'Everything in Starter',
      'Unlimited hypothesis generation',
      'Cross-paper discovery',
      'Experiment planning',
      'Advanced simulations',
      'Priority support',
      'API access',
    ],
    highlighted: true,
    cta: 'Start Researching',
  },
];

export const features: Feature[] = [
  {
    id: '1',
    title: 'AI Knowledge Engine',
    description: 'Process and understand millions of research papers to extract insights and connections.',
    icon: 'Brain',
  },
  {
    id: '2',
    title: 'Hypothesis Generator',
    description: 'Generate novel hypotheses based on cross-disciplinary research and knowledge graphs.',
    icon: 'Lightbulb',
  },
  {
    id: '3',
    title: 'Reality Simulation Engine',
    description: 'Predict experimental outcomes with AI-powered simulations before running physical tests.',
    icon: 'Cpu',
  },
  {
    id: '4',
    title: 'Experiment Planner',
    description: 'Get step-by-step guidance for testing your hypotheses with optimal experimental design.',
    icon: 'FlaskConical',
  },
];

export const useCases: UseCase[] = [
  {
    id: 'medicine',
    title: 'Medicine',
    description: 'Discover drug targets and predict molecular interactions for accelerated drug development.',
    icon: 'Pill',
    color: '#ef4444',
  },
  {
    id: 'energy',
    title: 'Energy',
    description: 'Design new battery materials and optimize energy storage systems with AI guidance.',
    icon: 'Zap',
    color: '#f59e0b',
  },
  {
    id: 'climate',
    title: 'Climate',
    description: 'Find carbon capture materials and model environmental interventions.',
    icon: 'Leaf',
    color: '#22c55e',
  },
  {
    id: 'chemistry',
    title: 'Chemistry',
    description: 'Predict chemical reactions and discover new catalysts for industrial processes.',
    icon: 'Beaker',
    color: '#3b82f6',
  },
];

export const mockChatMessages: ChatMessage[] = [
  {
    id: '1',
    role: 'user',
    content: 'Find catalysts for hydrogen production',
    timestamp: new Date(Date.now() - 3600000),
  },
  {
    id: '2',
    role: 'assistant',
    content: 'Based on recent research, here are the most effective catalysts for hydrogen production:\n\n**Top Catalysts:**\n• Platinum nanoparticles - Highest efficiency (90%+), but expensive\n• Nickel-molybdenum alloys - Cost-effective with good activity\n• Cobalt phosphide (CoP) - Emerging low-cost alternative\n• MoS₂ nanosheets - Excellent for electrocatalytic HER\n\n**Key Research Findings:**\nTransition metal phosphides show promise as Pt alternatives, with CoP achieving 85% of Pt activity at 1/100th the cost.',
    timestamp: new Date(Date.now() - 3540000),
    attachments: [
      {
        id: 'a1',
        type: 'paper',
        title: 'Recent Advances in HER Catalysts',
        content: 'Review of 2024 catalyst developments...',
      },
    ],
  },
];

// Weekly data for charts
export const weeklyQueriesData = [
  { day: 'Mon', queries: 45, hypotheses: 8 },
  { day: 'Tue', queries: 52, hypotheses: 12 },
  { day: 'Wed', queries: 38, hypotheses: 6 },
  { day: 'Thu', queries: 65, hypotheses: 15 },
  { day: 'Fri', queries: 48, hypotheses: 10 },
  { day: 'Sat', queries: 32, hypotheses: 5 },
  { day: 'Sun', queries: 28, hypotheses: 4 },
];

export const monthlyGrowthData = [
  { month: 'Jan', users: 120, queries: 1200 },
  { month: 'Feb', users: 180, queries: 2100 },
  { month: 'Mar', users: 250, queries: 3200 },
  { month: 'Apr', users: 340, queries: 4500 },
  { month: 'May', users: 450, queries: 6100 },
  { month: 'Jun', users: 580, queries: 8200 },
];
