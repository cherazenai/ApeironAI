import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import LandingPage from '@/pages/LandingPage';
import AuthPage from '@/pages/AuthPage';
import DashboardLayout from '@/layouts/DashboardLayout';
import Dashboard from '@/pages/dashboard/Dashboard';
import ResearchCopilot from '@/pages/dashboard/ResearchCopilot';
import HypothesisGenerator from '@/pages/dashboard/HypothesisGenerator';
import PaperLibrary from '@/pages/dashboard/PaperLibrary';
import Simulations from '@/pages/dashboard/Simulations';
import Experiments from '@/pages/dashboard/Experiments';
import SavedProjects from '@/pages/dashboard/SavedProjects';
import Profile from '@/pages/dashboard/Profile';
import Settings from '@/pages/dashboard/Settings';
import AdminDashboard from '@/pages/admin/AdminDashboard';
import { Loader2 } from 'lucide-react';

// Loading screen component
function LoadingScreen() {
  return (
    <div className="fixed inset-0 bg-black flex items-center justify-center z-50">
      <div className="flex flex-col items-center gap-6">
        <div className="relative w-20 h-20">
          <img 
            src="/logo.png" 
            alt="ApeironAI" 
            className="w-full h-full object-contain animate-pulse"
          />
          <div className="absolute inset-0 bg-apeiron-cyan/20 blur-xl rounded-full animate-pulse" />
        </div>
        <div className="flex items-center gap-2 text-apeiron-gray">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span className="text-sm">Loading...</span>
        </div>
      </div>
    </div>
  );
}

// Main app content with routing
function AppContent() {
  const { isAuthenticated, user, isLoading } = useAuth();
  const [currentView, setCurrentView] = useState<string>('landing');
  const [isAppLoading, setIsAppLoading] = useState(true);

  useEffect(() => {
    // Simulate initial app loading
    const timer = setTimeout(() => {
      setIsAppLoading(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (isAuthenticated) {
      setCurrentView(user?.role === 'admin' ? 'admin' : 'dashboard');
    } else {
      setCurrentView('landing');
    }
  }, [isAuthenticated, user]);

  if (isAppLoading || isLoading) {
    return <LoadingScreen />;
  }

  // Auth pages
  if (currentView === 'login' || currentView === 'signup' || currentView === 'forgot-password') {
    return <AuthPage view={currentView} onViewChange={setCurrentView} />;
  }

  // Landing page
  if (currentView === 'landing') {
    return (
      <LandingPage 
        onLogin={() => setCurrentView('login')} 
        onGetStarted={() => setCurrentView('signup')}
      />
    );
  }

  // Admin dashboard
  if (currentView === 'admin' && user?.role === 'admin') {
    return (
      <DashboardLayout 
        currentView={currentView} 
        onViewChange={setCurrentView}
        isAdmin={true}
      >
        <AdminDashboard />
      </DashboardLayout>
    );
  }

  // User dashboard views
  const renderDashboardContent = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard />;
      case 'research-copilot':
        return <ResearchCopilot />;
      case 'hypothesis-generator':
        return <HypothesisGenerator />;
      case 'paper-library':
        return <PaperLibrary />;
      case 'simulations':
        return <Simulations />;
      case 'experiments':
        return <Experiments />;
      case 'saved-projects':
        return <SavedProjects />;
      case 'profile':
        return <Profile />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <DashboardLayout 
      currentView={currentView} 
      onViewChange={setCurrentView}
      isAdmin={user?.role === 'admin'}
    >
      {renderDashboardContent()}
    </DashboardLayout>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
