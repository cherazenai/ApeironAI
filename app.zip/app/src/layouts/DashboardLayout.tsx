import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, MessageSquare, Lightbulb, BookOpen,
  Cpu, FlaskConical, FolderOpen, User, Settings,
  Users, BarChart3, Shield, LogOut, Menu, X,
  ChevronLeft, ChevronRight, Bell
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

interface DashboardLayoutProps {
  children: React.ReactNode;
  currentView: string;
  onViewChange: (view: string) => void;
  isAdmin?: boolean;
}

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  badge?: number;
}

const userNavItems: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'research-copilot', label: 'Research Copilot', icon: MessageSquare },
  { id: 'hypothesis-generator', label: 'Hypothesis Generator', icon: Lightbulb },
  { id: 'paper-library', label: 'Paper Library', icon: BookOpen, badge: 3 },
  { id: 'simulations', label: 'Simulations', icon: Cpu },
  { id: 'experiments', label: 'Experiments', icon: FlaskConical },
  { id: 'saved-projects', label: 'Saved Projects', icon: FolderOpen },
];

const adminNavItems: NavItem[] = [
  { id: 'admin', label: 'Overview', icon: LayoutDashboard },
  { id: 'admin-users', label: 'User Management', icon: Users },
  { id: 'admin-analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'admin-system', label: 'System Health', icon: Shield },
];

const bottomNavItems: NavItem[] = [
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export default function DashboardLayout({ 
  children, 
  currentView, 
  onViewChange,
  isAdmin = false 
}: DashboardLayoutProps) {
  const { user, logout } = useAuth();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = isAdmin ? adminNavItems : userNavItems;

  const handleLogout = () => {
    logout();
    onViewChange('landing');
  };

  return (
    <div className="min-h-screen bg-black flex">
      {/* Desktop Sidebar */}
      <motion.aside
        initial={false}
        animate={{ width: isSidebarCollapsed ? 80 : 280 }}
        className="hidden lg:flex flex-col bg-[#0A0A0A] border-r border-white/5 fixed h-full z-40"
      >
        {/* Logo */}
        <div className="h-16 flex items-center px-4 border-b border-white/5">
          <div className="flex items-center gap-3 overflow-hidden">
            <img src="/logo.png" alt="ApeironAI" className="w-8 h-8 flex-shrink-0" />
            {!isSidebarCollapsed && (
              <span className="text-lg font-semibold text-white whitespace-nowrap">ApeironAI</span>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto custom-scrollbar">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onViewChange(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${
                  isActive 
                    ? 'bg-apeiron-cyan/10 text-apeiron-cyan' 
                    : 'text-apeiron-gray hover:text-white hover:bg-white/5'
                }`}
                title={isSidebarCollapsed ? item.label : undefined}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                {!isSidebarCollapsed && (
                  <>
                    <span className="text-sm font-medium flex-1 text-left">{item.label}</span>
                    {item.badge && (
                      <span className="bg-apeiron-cyan/20 text-apeiron-cyan text-xs px-2 py-0.5 rounded-full">
                        {item.badge}
                      </span>
                    )}
                  </>
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom Navigation */}
        <div className="py-4 px-3 border-t border-white/5 space-y-1">
          {bottomNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onViewChange(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${
                  isActive 
                    ? 'bg-apeiron-cyan/10 text-apeiron-cyan' 
                    : 'text-apeiron-gray hover:text-white hover:bg-white/5'
                }`}
                title={isSidebarCollapsed ? item.label : undefined}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                {!isSidebarCollapsed && <span className="text-sm font-medium">{item.label}</span>}
              </button>
            );
          })}
          
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-apeiron-gray hover:text-red-400 hover:bg-red-500/10 transition-all"
            title={isSidebarCollapsed ? 'Logout' : undefined}
          >
            <LogOut className="w-5 h-5 flex-shrink-0" />
            {!isSidebarCollapsed && <span className="text-sm font-medium">Logout</span>}
          </button>
        </div>

        {/* Collapse button */}
        <button
          onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          className="absolute -right-3 top-20 w-6 h-6 bg-[#111111] border border-white/10 rounded-full flex items-center justify-center text-apeiron-gray hover:text-white transition-colors"
        >
          {isSidebarCollapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronLeft className="w-3 h-3" />}
        </button>
      </motion.aside>

      {/* Mobile Sidebar */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="lg:hidden fixed inset-0 bg-black/80 backdrop-blur-sm z-40"
            />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="lg:hidden fixed left-0 top-0 bottom-0 w-72 bg-[#0A0A0A] border-r border-white/5 z-50 flex flex-col"
            >
              {/* Mobile Header */}
              <div className="h-16 flex items-center justify-between px-4 border-b border-white/5">
                <div className="flex items-center gap-3">
                  <img src="/logo.png" alt="ApeironAI" className="w-8 h-8" />
                  <span className="text-lg font-semibold text-white">ApeironAI</span>
                </div>
                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-2 text-apeiron-gray hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Mobile Navigation */}
              <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = currentView === item.id;
                  
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onViewChange(item.id);
                        setIsMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-all ${
                        isActive 
                          ? 'bg-apeiron-cyan/10 text-apeiron-cyan' 
                          : 'text-apeiron-gray hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="text-sm font-medium flex-1 text-left">{item.label}</span>
                      {item.badge && (
                        <span className="bg-apeiron-cyan/20 text-apeiron-cyan text-xs px-2 py-0.5 rounded-full">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </nav>

              {/* Mobile Bottom Navigation */}
              <div className="py-4 px-3 border-t border-white/5 space-y-1">
                {bottomNavItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onViewChange(item.id);
                        setIsMobileMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-3 px-3 py-3 rounded-lg text-apeiron-gray hover:text-white hover:bg-white/5 transition-all"
                    >
                      <Icon className="w-5 h-5" />
                      <span className="text-sm font-medium">{item.label}</span>
                    </button>
                  );
                })}
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-lg text-apeiron-gray hover:text-red-400 hover:bg-red-500/10 transition-all"
                >
                  <LogOut className="w-5 h-5" />
                  <span className="text-sm font-medium">Logout</span>
                </button>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className={`flex-1 min-h-screen transition-all duration-300 ${
        isSidebarCollapsed ? 'lg:ml-20' : 'lg:ml-[280px]'
      }`}>
        {/* Header */}
        <header className="h-16 bg-[#0A0A0A]/80 backdrop-blur-xl border-b border-white/5 sticky top-0 z-30">
          <div className="h-full px-4 md:px-6 flex items-center justify-between">
            {/* Left side */}
            <div className="flex items-center gap-4">
              <button
                onClick={() => setIsMobileMenuOpen(true)}
                className="lg:hidden p-2 text-apeiron-gray hover:text-white"
              >
                <Menu className="w-5 h-5" />
              </button>
              <h1 className="text-lg font-semibold text-white capitalize">
                {currentView.replace(/-/g, ' ').replace('admin ', '')}
              </h1>
            </div>

            {/* Right side */}
            <div className="flex items-center gap-4">
              <button className="relative p-2 text-apeiron-gray hover:text-white transition-colors">
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-apeiron-cyan rounded-full" />
              </button>
              
              <div className="flex items-center gap-3">
                <div className="text-right hidden sm:block">
                  <p className="text-sm text-white font-medium">{user?.name}</p>
                  <p className="text-xs text-apeiron-gray capitalize">{user?.plan} Plan</p>
                </div>
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-apeiron-cyan to-apeiron-cyan-dark flex items-center justify-center">
                  <span className="text-black font-medium text-sm">
                    {user?.name?.charAt(0).toUpperCase()}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="p-4 md:p-6">
          {children}
        </div>
      </main>
    </div>
  );
}
