import { useEffect, useRef, useState } from 'react';
import { motion, useScroll, useTransform, useInView } from 'framer-motion';
import { 
  Brain, Lightbulb, Cpu, FlaskConical, 
  ArrowRight, Check, Play, ChevronRight,
  Pill, Zap, Leaf, Beaker, Menu, X
} from 'lucide-react';
import { features, useCases, pricingPlans } from '@/lib/mockData';

interface LandingPageProps {
  onLogin: () => void;
  onGetStarted: () => void;
}

// Animated section wrapper
function AnimatedSection({ children, className = '', delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

// Navbar component
function Navbar({ onLogin, onGetStarted }: { onLogin: () => void; onGetStarted: () => void }) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Overview', href: '#overview' },
    { label: 'Features', href: '#features' },
    { label: 'Demo', href: '#demo' },
    { label: 'Pricing', href: '#pricing' },
  ];

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-black/80 backdrop-blur-xl border-b border-white/5' : ''
      }`}
    >
      <div className="section-padding">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <a href="#" className="flex items-center gap-3">
            <img src="/logo.png" alt="ApeironAI" className="w-8 h-8 md:w-10 md:h-10" />
            <span className="text-xl font-semibold text-white hidden sm:block">ApeironAI</span>
          </a>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-sm text-apeiron-gray hover:text-white transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center gap-4">
            <button
              onClick={onLogin}
              className="text-sm text-apeiron-gray hover:text-white transition-colors"
            >
              Log in
            </button>
            <button
              onClick={onGetStarted}
              className="btn-glow text-sm py-2 px-4"
            >
              Get Started
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 text-white"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden bg-black/95 backdrop-blur-xl border-b border-white/10"
        >
          <div className="section-padding py-4 space-y-4">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className="block text-apeiron-gray hover:text-white transition-colors"
              >
                {link.label}
              </a>
            ))}
            <div className="pt-4 border-t border-white/10 space-y-3">
              <button
                onClick={() => { onLogin(); setIsMobileMenuOpen(false); }}
                className="block w-full text-left text-apeiron-gray"
              >
                Log in
              </button>
              <button
                onClick={() => { onGetStarted(); setIsMobileMenuOpen(false); }}
                className="btn-glow w-full text-center"
              >
                Get Started
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
}

// Hero Section
function HeroSection({ onGetStarted }: { onGetStarted: () => void }) {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end start'],
  });
  
  const y = useTransform(scrollYProgress, [0, 1], [0, 150]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  return (
    <section ref={containerRef} className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-apeiron-cyan/5 via-transparent to-transparent" />
      
      {/* Animated background orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{ 
            x: [0, 100, 0], 
            y: [0, -50, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
          className="absolute top-1/4 left-1/4 w-96 h-96 bg-apeiron-cyan/10 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ 
            x: [0, -100, 0], 
            y: [0, 50, 0],
            scale: [1, 1.3, 1],
          }}
          transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
          className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-apeiron-cyan-dark/10 rounded-full blur-3xl"
        />
      </div>

      <motion.div 
        style={{ y, opacity }}
        className="relative z-10 section-padding w-full"
      >
        <div className="container-max text-center">
          {/* Logo animation */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="mb-8"
          >
            <div className="relative inline-block">
              <img 
                src="/logo.png" 
                alt="ApeironAI" 
                className="w-24 h-24 md:w-32 md:h-32 mx-auto"
              />
              <div className="absolute inset-0 bg-apeiron-cyan/30 blur-3xl rounded-full animate-pulse" />
            </div>
          </motion.div>

          {/* Title */}
          <motion.h1
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-6 tracking-tight"
          >
            ApeironAI
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-xl md:text-2xl lg:text-3xl gradient-text font-medium mb-4"
          >
            AI Reality Simulator + Scientific Discovery Engine
          </motion.p>

          {/* Description */}
          <motion.p
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-base md:text-lg text-apeiron-gray max-w-2xl mx-auto mb-10"
          >
            Accelerating scientific discovery with AI-powered hypothesis generation, 
            cross-paper knowledge synthesis, and predictive simulation.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <button onClick={onGetStarted} className="btn-glow flex items-center gap-2">
              Start Research
              <ArrowRight className="w-4 h-4" />
            </button>
            <button className="btn-outline-glow flex items-center gap-2">
              <Play className="w-4 h-4" />
              Watch Demo
            </button>
          </motion.div>

          {/* Trust badges */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.7 }}
            className="mt-16 pt-8 border-t border-white/5"
          >
            <p className="text-sm text-apeiron-gray mb-6">Trusted by researchers at</p>
            <div className="flex flex-wrap items-center justify-center gap-8 opacity-50">
              {['MIT', 'Stanford', 'Oxford', 'Cambridge', 'ETH Zurich'].map((uni) => (
                <span key={uni} className="text-white font-medium">{uni}</span>
              ))}
            </div>
          </motion.div>
        </div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="w-6 h-10 border-2 border-white/20 rounded-full flex justify-center pt-2"
        >
          <div className="w-1 h-2 bg-apeiron-cyan rounded-full" />
        </motion.div>
      </motion.div>
    </section>
  );
}

// Features Section
function FeaturesSection() {
  const iconMap: Record<string, React.ElementType> = {
    Brain, Lightbulb, Cpu, FlaskConical,
  };

  return (
    <section id="features" className="py-24 md:py-32 relative">
      <div className="section-padding">
        <div className="container-max">
          <AnimatedSection className="text-center mb-16">
            <span className="text-apeiron-cyan text-sm font-medium uppercase tracking-wider">Features</span>
            <h2 className="text-3xl md:text-5xl font-bold text-white mt-4 mb-6">
              Everything you need to<br />
              <span className="gradient-text">accelerate discovery</span>
            </h2>
            <p className="text-apeiron-gray max-w-2xl mx-auto">
              Our AI-powered platform combines knowledge graphs, large language models, 
              and simulation engines to transform how you do research.
            </p>
          </AnimatedSection>

          <div className="grid md:grid-cols-2 gap-6">
            {features.map((feature, index) => {
              const Icon = iconMap[feature.icon];
              return (
                <AnimatedSection key={feature.id} delay={index * 0.1}>
                  <div className="glass-card-hover p-8 h-full group">
                    <div className="w-14 h-14 rounded-xl bg-apeiron-cyan/10 flex items-center justify-center mb-6 group-hover:bg-apeiron-cyan/20 transition-colors">
                      <Icon className="w-7 h-7 text-apeiron-cyan" />
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-3">{feature.title}</h3>
                    <p className="text-apeiron-gray leading-relaxed">{feature.description}</p>
                  </div>
                </AnimatedSection>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

// Demo Section
function DemoSection() {
  const [isTyping, setIsTyping] = useState(true);
  const [displayedText, setDisplayedText] = useState('');
  const fullText = 'Suggest new battery chemistry to improve energy density';

  useEffect(() => {
    if (isTyping) {
      let index = 0;
      const timer = setInterval(() => {
        if (index <= fullText.length) {
          setDisplayedText(fullText.slice(0, index));
          index++;
        } else {
          setIsTyping(false);
          clearInterval(timer);
        }
      }, 50);
      return () => clearInterval(timer);
    }
  }, [isTyping]);

  return (
    <section id="demo" className="py-24 md:py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-apeiron-cyan/5 to-transparent" />
      
      <div className="section-padding relative">
        <div className="container-max">
          <AnimatedSection className="text-center mb-16">
            <span className="text-apeiron-cyan text-sm font-medium uppercase tracking-wider">Product Demo</span>
            <h2 className="text-3xl md:text-5xl font-bold text-white mt-4 mb-6">
              See ApeironAI in action
            </h2>
          </AnimatedSection>

          <AnimatedSection delay={0.2}>
            <div className="glass-card overflow-hidden max-w-4xl mx-auto">
              {/* Mock browser header */}
              <div className="flex items-center gap-2 px-4 py-3 bg-[#111111] border-b border-white/10">
                <div className="flex gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500/80" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                  <div className="w-3 h-3 rounded-full bg-green-500/80" />
                </div>
                <div className="flex-1 mx-4">
                  <div className="bg-black/50 rounded-md px-4 py-1.5 text-sm text-apeiron-gray flex items-center justify-center gap-2">
                    <img src="/logo.png" alt="" className="w-4 h-4" />
                    apeiron.ai/research
                  </div>
                </div>
              </div>

              {/* Mock content */}
              <div className="p-6 md:p-8">
                {/* Chat interface */}
                <div className="space-y-6">
                  {/* User message */}
                  <div className="flex gap-4">
                    <div className="w-8 h-8 rounded-full bg-apeiron-cyan/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-apeiron-cyan text-sm font-medium">U</span>
                    </div>
                    <div className="flex-1">
                      <div className="bg-[#111111] rounded-lg px-4 py-3 inline-block">
                        <span className="text-white">{displayedText}</span>
                        {isTyping && <span className="animate-pulse text-apeiron-cyan">|</span>}
                      </div>
                    </div>
                  </div>

                  {/* AI response */}
                  {!isTyping && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex gap-4"
                    >
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-apeiron-cyan to-apeiron-cyan-dark flex items-center justify-center flex-shrink-0">
                        <img src="/logo.png" alt="" className="w-5 h-5" />
                      </div>
                      <div className="flex-1 space-y-4">
                        <div className="bg-[#111111] rounded-lg px-4 py-3">
                          <p className="text-white mb-4">
                            Based on recent research, here are promising battery chemistries for improved energy density:
                          </p>
                          <ul className="space-y-2 text-apeiron-gray">
                            <li className="flex items-start gap-2">
                              <ChevronRight className="w-4 h-4 text-apeiron-cyan mt-0.5 flex-shrink-0" />
                              <span><strong className="text-white">Solid-state lithium-metal</strong> - 400+ Wh/kg potential</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <ChevronRight className="w-4 h-4 text-apeiron-cyan mt-0.5 flex-shrink-0" />
                              <span><strong className="text-white">Lithium-sulfur</strong> - 500 Wh/kg theoretical</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <ChevronRight className="w-4 h-4 text-apeiron-cyan mt-0.5 flex-shrink-0" />
                              <span><strong className="text-white">Silicon nanowire anodes</strong> - 10x capacity vs graphite</span>
                            </li>
                          </ul>
                        </div>

                        {/* Supporting papers */}
                        <div className="flex flex-wrap gap-2">
                          <span className="text-xs text-apeiron-gray uppercase tracking-wider">Supporting Research:</span>
                          {['Nature Energy 2024', 'J. Power Sources', 'Adv. Materials'].map((paper) => (
                            <span key={paper} className="text-xs bg-apeiron-cyan/10 text-apeiron-cyan px-2 py-1 rounded">
                              {paper}
                            </span>
                          ))}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </div>

                {/* Input area */}
                <div className="mt-6 pt-6 border-t border-white/10">
                  <div className="flex items-center gap-3 bg-[#111111] rounded-lg px-4 py-3">
                    <input
                      type="text"
                      placeholder="Ask a research question..."
                      className="flex-1 bg-transparent text-white placeholder:text-apeiron-gray outline-none"
                      readOnly
                    />
                    <button className="btn-glow py-2 px-4 text-sm">Send</button>
                  </div>
                </div>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  );
}

// Use Cases Section
function UseCasesSection() {
  const iconMap: Record<string, React.ElementType> = {
    Pill, Zap, Leaf, Beaker,
  };

  return (
    <section className="py-24 md:py-32 relative">
      <div className="section-padding">
        <div className="container-max">
          <AnimatedSection className="text-center mb-16">
            <span className="text-apeiron-cyan text-sm font-medium uppercase tracking-wider">Use Cases</span>
            <h2 className="text-3xl md:text-5xl font-bold text-white mt-4 mb-6">
              Research across disciplines
            </h2>
            <p className="text-apeiron-gray max-w-2xl mx-auto">
              From drug discovery to climate science, ApeironAI accelerates research 
              across every scientific domain.
            </p>
          </AnimatedSection>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {useCases.map((useCase, index) => {
              const Icon = iconMap[useCase.icon];
              return (
                <AnimatedSection key={useCase.id} delay={index * 0.1}>
                  <div className="glass-card-hover p-6 h-full text-center group">
                    <div 
                      className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-5 transition-transform group-hover:scale-110"
                      style={{ backgroundColor: `${useCase.color}20` }}
                    >
                      <Icon className="w-8 h-8" style={{ color: useCase.color }} />
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-2">{useCase.title}</h3>
                    <p className="text-sm text-apeiron-gray">{useCase.description}</p>
                  </div>
                </AnimatedSection>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

// Technology Section
function TechnologySection() {
  const steps = [
    { label: 'Research Data', icon: 'Database', description: 'Ingest millions of papers' },
    { label: 'Knowledge Graph', icon: 'Network', description: 'Connect concepts across domains' },
    { label: 'AI Reasoning', icon: 'Brain', description: 'Apply LLM reasoning' },
    { label: 'Hypothesis Generation', icon: 'Lightbulb', description: 'Generate novel hypotheses' },
    { label: 'Simulation Engine', icon: 'Cpu', description: 'Predict outcomes' },
  ];

  return (
    <section className="py-24 md:py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-apeiron-cyan/5 via-transparent to-transparent" />
      
      <div className="section-padding relative">
        <div className="container-max">
          <AnimatedSection className="text-center mb-16">
            <span className="text-apeiron-cyan text-sm font-medium uppercase tracking-wider">Technology</span>
            <h2 className="text-3xl md:text-5xl font-bold text-white mt-4 mb-6">
              How it works
            </h2>
          </AnimatedSection>

          <AnimatedSection delay={0.2}>
            <div className="relative">
              {/* Connection line */}
              <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-apeiron-cyan/30 to-transparent -translate-y-1/2" />
              
              <div className="grid lg:grid-cols-5 gap-6">
                {steps.map((step, index) => (
                  <motion.div
                    key={step.label}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.15 }}
                    viewport={{ once: true }}
                    className="relative"
                  >
                    <div className="glass-card p-6 text-center group hover:border-apeiron-cyan/30 transition-colors">
                      <div className="w-12 h-12 rounded-xl bg-apeiron-cyan/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-apeiron-cyan/20 transition-colors">
                        <span className="text-apeiron-cyan font-bold">{index + 1}</span>
                      </div>
                      <h3 className="text-white font-medium mb-1">{step.label}</h3>
                      <p className="text-sm text-apeiron-gray">{step.description}</p>
                    </div>
                    
                    {/* Arrow for mobile */}
                    {index < steps.length - 1 && (
                      <div className="lg:hidden flex justify-center my-4">
                        <ArrowRight className="w-5 h-5 text-apeiron-cyan rotate-90" />
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  );
}

// Pricing Section
function PricingSection({ onGetStarted }: { onGetStarted: () => void }) {
  return (
    <section id="pricing" className="py-24 md:py-32 relative">
      <div className="section-padding">
        <div className="container-max">
          <AnimatedSection className="text-center mb-16">
            <span className="text-apeiron-cyan text-sm font-medium uppercase tracking-wider">Pricing</span>
            <h2 className="text-3xl md:text-5xl font-bold text-white mt-4 mb-6">
              Simple, transparent pricing
            </h2>
            <p className="text-apeiron-gray max-w-2xl mx-auto">
              Start free and upgrade when you need more power. No hidden fees.
            </p>
          </AnimatedSection>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {pricingPlans.map((plan, index) => (
              <AnimatedSection key={plan.id} delay={index * 0.1}>
                <div className={`relative p-8 rounded-2xl ${
                  plan.highlighted 
                    ? 'bg-gradient-to-b from-apeiron-cyan/20 to-transparent border border-apeiron-cyan/30' 
                    : 'glass-card'
                }`}>
                  {plan.highlighted && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                      <span className="bg-apeiron-cyan text-black text-xs font-medium px-3 py-1 rounded-full">
                        Most Popular
                      </span>
                    </div>
                  )}
                  
                  <div className="mb-6">
                    <h3 className="text-xl font-semibold text-white mb-2">{plan.name}</h3>
                    <p className="text-apeiron-gray text-sm">{plan.description}</p>
                  </div>

                  <div className="mb-8">
                    <span className="text-4xl font-bold text-white">${plan.price}</span>
                    <span className="text-apeiron-gray">/{plan.period}</span>
                  </div>

                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-apeiron-cyan flex-shrink-0 mt-0.5" />
                        <span className="text-apeiron-gray text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <button 
                    onClick={onGetStarted}
                    className={`w-full py-3 rounded-lg font-medium transition-all ${
                      plan.highlighted 
                        ? 'btn-glow' 
                        : 'bg-white/5 text-white hover:bg-white/10 border border-white/10'
                    }`}
                  >
                    {plan.cta}
                  </button>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// Footer
function Footer() {
  const footerLinks = {
    Product: ['Features', 'Pricing', 'API', 'Integrations'],
    Company: ['About', 'Blog', 'Careers', 'Press'],
    Resources: ['Documentation', 'Tutorials', 'Support', 'Community'],
    Legal: ['Privacy', 'Terms', 'Security', 'Cookies'],
  };

  return (
    <footer className="py-16 border-t border-white/5">
      <div className="section-padding">
        <div className="container-max">
          <div className="grid md:grid-cols-6 gap-12 mb-12">
            {/* Logo and description */}
            <div className="md:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <img src="/logo.png" alt="ApeironAI" className="w-10 h-10" />
                <span className="text-xl font-semibold text-white">ApeironAI</span>
              </div>
              <p className="text-apeiron-gray text-sm mb-6 max-w-xs">
                Accelerating scientific discovery with AI-powered hypothesis generation and simulation.
              </p>
              <p className="text-apeiron-gray text-xs">
                © 2024 Cherazen Inc. All rights reserved.
              </p>
            </div>

            {/* Links */}
            {Object.entries(footerLinks).map(([category, links]) => (
              <div key={category}>
                <h4 className="text-white font-medium mb-4">{category}</h4>
                <ul className="space-y-2">
                  {links.map((link) => (
                    <li key={link}>
                      <a href="#" className="text-apeiron-gray text-sm hover:text-white transition-colors">
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Bottom bar */}
          <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-apeiron-gray text-xs">
              Founded by Manish Talukdar
            </p>
            <div className="flex items-center gap-6">
              <a href="#" className="text-apeiron-gray hover:text-white transition-colors">
                <span className="sr-only">Twitter</span>
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
              </a>
              <a href="#" className="text-apeiron-gray hover:text-white transition-colors">
                <span className="sr-only">GitHub</span>
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>
              </a>
              <a href="#" className="text-apeiron-gray hover:text-white transition-colors">
                <span className="sr-only">LinkedIn</span>
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

// Main Landing Page Component
export default function LandingPage({ onLogin, onGetStarted }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-black">
      <Navbar onLogin={onLogin} onGetStarted={onGetStarted} />
      <main>
        <HeroSection onGetStarted={onGetStarted} />
        <div id="overview">
          <FeaturesSection />
        </div>
        <DemoSection />
        <UseCasesSection />
        <TechnologySection />
        <PricingSection onGetStarted={onGetStarted} />
      </main>
      <Footer />
    </div>
  );
}
