import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Cpu, Play, RotateCcw, Download, Eye, Trash2,
  Beaker, FlaskConical, TrendingUp, Clock, CheckCircle2,
  XCircle, Loader2, Plus
} from 'lucide-react';
import { mockSimulations } from '@/lib/mockData';
import type { Simulation } from '@/types';

const simulationTypes = [
  { id: 'material', label: 'Material Properties', icon: Beaker, description: 'Simulate material behavior under various conditions' },
  { id: 'reaction', label: 'Chemical Reaction', icon: FlaskConical, description: 'Model reaction kinetics and pathways' },
  { id: 'experiment', label: 'Experiment Design', icon: TrendingUp, description: 'Optimize experimental parameters' },
];

const statusConfig = {
  pending: { color: '#f59e0b', icon: Clock, label: 'Pending' },
  running: { color: '#2ab4d9', icon: Loader2, label: 'Running' },
  completed: { color: '#22c55e', icon: CheckCircle2, label: 'Completed' },
  failed: { color: '#ef4444', icon: XCircle, label: 'Failed' },
};

export default function Simulations() {
  const [simulations, setSimulations] = useState<Simulation[]>(mockSimulations);
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [selectedSimulation, setSelectedSimulation] = useState<Simulation | null>(null);

  const handleRunSimulation = (id: string) => {
    setSimulations(simulations.map(s => 
      s.id === id ? { ...s, status: 'running' } : s
    ));
    
    // Simulate completion
    setTimeout(() => {
      setSimulations(simulations.map(s => 
        s.id === id ? { 
          ...s, 
          status: 'completed',
          completedAt: new Date(),
          results: { 
            capacityRetention: Math.floor(Math.random() * 20) + 80,
            efficiency: Math.floor(Math.random() * 15) + 85
          }
        } : s
      ));
    }, 5000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-6"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1 flex items-center gap-3">
              <Cpu className="w-7 h-7 text-apeiron-cyan" />
              Simulations
            </h2>
            <p className="text-apeiron-gray">
              Run AI-powered simulations to predict experimental outcomes.
            </p>
          </div>
          <button
            onClick={() => setIsNewModalOpen(true)}
            className="btn-glow flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            New Simulation
          </button>
        </div>
      </motion.div>

      {/* Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-4"
      >
        {[
          { label: 'Total', value: simulations.length, color: '#2ab4d9' },
          { label: 'Running', value: simulations.filter(s => s.status === 'running').length, color: '#f59e0b' },
          { label: 'Completed', value: simulations.filter(s => s.status === 'completed').length, color: '#22c55e' },
          { label: 'Failed', value: simulations.filter(s => s.status === 'failed').length, color: '#ef4444' },
        ].map((stat) => (
          <div key={stat.label} className="glass-card p-4 text-center">
            <p className="text-2xl font-bold mb-1" style={{ color: stat.color }}>{stat.value}</p>
            <p className="text-sm text-apeiron-gray">{stat.label}</p>
          </div>
        ))}
      </motion.div>

      {/* Simulation Types */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="grid md:grid-cols-3 gap-4"
      >
        {simulationTypes.map((type) => {
          const Icon = type.icon;
          return (
            <button
              key={type.id}
              onClick={() => setSelectedType(selectedType === type.id ? null : type.id)}
              className={`glass-card-hover p-5 text-left transition-all ${
                selectedType === type.id ? 'border-apeiron-cyan/50' : ''
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-apeiron-cyan/10 flex items-center justify-center mb-4">
                <Icon className="w-6 h-6 text-apeiron-cyan" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">{type.label}</h3>
              <p className="text-sm text-apeiron-gray">{type.description}</p>
            </button>
          );
        })}
      </motion.div>

      {/* Simulations List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="space-y-3"
      >
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-white">Recent Simulations</h3>
          <button className="text-sm text-apeiron-cyan hover:text-apeiron-cyan-light transition-colors">
            View all
          </button>
        </div>

        {simulations.map((simulation, index) => {
          const status = statusConfig[simulation.status];
          const StatusIcon = status.icon;
          
          return (
            <motion.div
              key={simulation.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25 + index * 0.05 }}
              className="glass-card-hover p-5"
            >
              <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                {/* Status Icon */}
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: `${status.color}20` }}
                >
                  <StatusIcon 
                    className={`w-6 h-6 ${simulation.status === 'running' ? 'animate-spin' : ''}`}
                    style={{ color: status.color }}
                  />
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-1">
                    <h4 className="text-lg font-medium text-white">{simulation.name}</h4>
                    <span 
                      className="px-2 py-0.5 text-xs rounded-full"
                      style={{ backgroundColor: `${status.color}20`, color: status.color }}
                    >
                      {status.label}
                    </span>
                  </div>
                  <p className="text-sm text-apeiron-gray capitalize">
                    {simulation.type} Simulation • Started {new Date(simulation.createdAt).toLocaleDateString()}
                  </p>
                  
                  {/* Parameters */}
                  <div className="flex flex-wrap gap-2 mt-2">
                    {Object.entries(simulation.parameters).map(([key, value]) => (
                      <span key={key} className="text-xs bg-white/5 text-apeiron-gray px-2 py-1 rounded">
                        {key}: {value}
                      </span>
                    ))}
                  </div>

                  {/* Results */}
                  {simulation.results && (
                    <div className="flex flex-wrap gap-4 mt-3 pt-3 border-t border-white/5">
                      {Object.entries(simulation.results).map(([key, value]) => (
                        <div key={key} className="flex items-center gap-2">
                          <span className="text-xs text-apeiron-gray capitalize">{key}:</span>
                          <span className="text-sm text-apeiron-cyan font-medium">{value}%</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2">
                  {simulation.status === 'pending' && (
                    <button
                      onClick={() => handleRunSimulation(simulation.id)}
                      className="p-2 bg-apeiron-cyan/10 text-apeiron-cyan rounded-lg hover:bg-apeiron-cyan/20 transition-colors"
                      title="Run"
                    >
                      <Play className="w-5 h-5" />
                    </button>
                  )}
                  {simulation.status === 'running' && (
                    <button
                      className="p-2 bg-yellow-500/10 text-yellow-500 rounded-lg cursor-not-allowed"
                      title="Running..."
                    >
                      <Loader2 className="w-5 h-5 animate-spin" />
                    </button>
                  )}
                  {simulation.status === 'completed' && (
                    <>
                      <button
                        onClick={() => setSelectedSimulation(simulation)}
                        className="p-2 text-apeiron-gray hover:text-white transition-colors"
                        title="View Results"
                      >
                        <Eye className="w-5 h-5" />
                      </button>
                      <button
                        className="p-2 text-apeiron-gray hover:text-white transition-colors"
                        title="Download"
                      >
                        <Download className="w-5 h-5" />
                      </button>
                    </>
                  )}
                  <button
                    className="p-2 text-apeiron-gray hover:text-red-400 transition-colors"
                    title="Delete"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </motion.div>

      {/* New Simulation Modal */}
      <AnimatePresence>
        {isNewModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setIsNewModalOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-card w-full max-w-lg max-h-[80vh] overflow-y-auto"
            >
              <div className="p-6">
                <h3 className="text-xl font-semibold text-white mb-6">New Simulation</h3>

                {/* Type Selection */}
                <div className="mb-6">
                  <label className="block text-sm text-apeiron-gray mb-3">Simulation Type</label>
                  <div className="grid grid-cols-3 gap-3">
                    {simulationTypes.map((type) => {
                      const Icon = type.icon;
                      return (
                        <button
                          key={type.id}
                          className={`p-4 rounded-lg border transition-all text-center ${
                            selectedType === type.id
                              ? 'bg-apeiron-cyan/10 border-apeiron-cyan'
                              : 'bg-white/5 border-white/10 hover:bg-white/10'
                          }`}
                          onClick={() => setSelectedType(type.id)}
                        >
                          <Icon className={`w-6 h-6 mx-auto mb-2 ${
                            selectedType === type.id ? 'text-apeiron-cyan' : 'text-apeiron-gray'
                          }`} />
                          <span className={`text-xs ${
                            selectedType === type.id ? 'text-white' : 'text-apeiron-gray'
                          }`}>
                            {type.label}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Name */}
                <div className="mb-4">
                  <label className="block text-sm text-apeiron-gray mb-2">Simulation Name</label>
                  <input
                    type="text"
                    className="input-field w-full"
                    placeholder="e.g., Battery Cycling Test"
                  />
                </div>

                {/* Parameters */}
                <div className="mb-6">
                  <label className="block text-sm text-apeiron-gray mb-3">Parameters</label>
                  <div className="space-y-3">
                    <div className="flex gap-3">
                      <input
                        type="text"
                        className="input-field flex-1"
                        placeholder="Parameter name"
                      />
                      <input
                        type="text"
                        className="input-field w-24"
                        placeholder="Value"
                      />
                    </div>
                    <div className="flex gap-3">
                      <input
                        type="text"
                        className="input-field flex-1"
                        placeholder="Parameter name"
                      />
                      <input
                        type="text"
                        className="input-field w-24"
                        placeholder="Value"
                      />
                    </div>
                  </div>
                  <button className="mt-3 text-sm text-apeiron-cyan hover:text-apeiron-cyan-light transition-colors flex items-center gap-1">
                    <Plus className="w-4 h-4" />
                    Add Parameter
                  </button>
                </div>

                {/* Actions */}
                <div className="flex gap-3">
                  <button
                    onClick={() => setIsNewModalOpen(false)}
                    className="flex-1 py-3 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      setIsNewModalOpen(false);
                      // Add new simulation
                    }}
                    className="btn-glow flex-1 flex items-center justify-center gap-2"
                  >
                    <Play className="w-4 h-4" />
                    Run Simulation
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Results Modal */}
      <AnimatePresence>
        {selectedSimulation && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedSimulation(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-card w-full max-w-2xl max-h-[80vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-xl font-semibold text-white">{selectedSimulation.name}</h3>
                    <p className="text-sm text-apeiron-gray">
                      Completed {selectedSimulation.completedAt?.toLocaleString()}
                    </p>
                  </div>
                  <button
                    onClick={() => setSelectedSimulation(null)}
                    className="p-2 text-apeiron-gray hover:text-white"
                  >
                    <XCircle className="w-6 h-6" />
                  </button>
                </div>

                {/* Results */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  {selectedSimulation.results && Object.entries(selectedSimulation.results).map(([key, value]) => (
                    <div key={key} className="glass-card p-4 text-center">
                      <p className="text-3xl font-bold text-apeiron-cyan mb-1">{value}%</p>
                      <p className="text-sm text-apeiron-gray capitalize">{key}</p>
                    </div>
                  ))}
                </div>

                {/* Charts Placeholder */}
                <div className="space-y-4">
                  <div className="glass-card p-4 h-48 flex items-center justify-center">
                    <p className="text-apeiron-gray">Simulation results visualization</p>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-3 mt-6">
                  <button className="btn-glow flex-1 flex items-center justify-center gap-2">
                    <Download className="w-4 h-4" />
                    Export Results
                  </button>
                  <button className="btn-outline-glow flex-1 flex items-center justify-center gap-2">
                    <RotateCcw className="w-4 h-4" />
                    Run Again
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
