import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Send, Paperclip, Sparkles, BookOpen, Lightbulb, FlaskConical,
  Copy, ThumbsUp, ThumbsDown, RotateCcw,
  Loader2, FileText
} from 'lucide-react';
import { mockChatMessages, mockPapers } from '@/lib/mockData';
import type { ChatMessage } from '@/types';

const suggestedQueries = [
  'Find catalysts for hydrogen production',
  'Suggest new battery chemistry to improve energy density',
  'Carbon capture materials for industrial applications',
  'Predict protein folding for drug targets',
  'Novel semiconductor materials for quantum computing',
];

const quickActions = [
  { label: 'Summarize', icon: FileText },
  { label: 'Hypothesize', icon: Lightbulb },
  { label: 'Simulate', icon: FlaskConical },
  { label: 'Find Papers', icon: BookOpen },
];

export default function ResearchCopilot() {
  const [messages, setMessages] = useState<ChatMessage[]>(mockChatMessages);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: generateAIResponse(inputValue),
        timestamp: new Date(),
        attachments: [
          {
            id: 'a1',
            type: 'paper',
            title: 'Related Research Papers',
            content: '3 papers found relevant to your query',
          },
        ],
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsLoading(false);
    }, 2000);
  };

  const generateAIResponse = (query: string): string => {
    const responses: Record<string, string> = {
      'catalyst': 'Based on recent research, effective catalysts for hydrogen production include:\n\n1. **Platinum nanoparticles** - Highest efficiency (90%+), but expensive\n2. **Nickel-molybdenum alloys** - Cost-effective with good activity\n3. **Cobalt phosphide (CoP)** - Emerging low-cost alternative\n4. **MoS₂ nanosheets** - Excellent for electrocatalytic HER\n\n**Key Research Findings:**\nTransition metal phosphides show promise as Pt alternatives, with CoP achieving 85% of Pt activity at 1/100th the cost. Recent studies in Nature Catalysis (2024) demonstrate improved stability through surface engineering.',
      'battery': 'Several promising battery chemistries for improved energy density:\n\n1. **Solid-state lithium-metal** - 400+ Wh/kg potential, eliminates dendrite issues\n2. **Lithium-sulfur** - 500 Wh/kg theoretical, challenges with polysulfide shuttle\n3. **Silicon nanowire anodes** - 10x capacity vs graphite, volume expansion managed\n4. **High-nickel NMC cathodes** - Ni-rich compositions reaching 300 mAh/g\n\n**Recommendation:**\nSolid-state designs with silicon-carbon composite anodes show the most promising path to 400+ Wh/kg in the near term.',
      'carbon': 'Leading carbon capture materials include:\n\n1. **Metal-organic frameworks (MOFs)** - Highest CO2 selectivity, tunable pore chemistry\n2. **Amine-functionalized adsorbents** - Mature technology, high capacity\n3. **Calcium looping materials** - Cost-effective for industrial scale\n4. **Zeolite 13X** - Proven performance, thermal stability\n\n**Breakthrough:**\nRecent MOF designs achieve >5 mmol/g CO2 uptake at low concentrations (<400 ppm), making direct air capture economically viable.',
    };

    const lowerQuery = query.toLowerCase();
    for (const [key, response] of Object.entries(responses)) {
      if (lowerQuery.includes(key)) return response;
    }

    return `I've analyzed your query about "${query}" and found several relevant research directions:\n\n**Key Insights:**\nBased on recent publications in top-tier journals, this area shows significant activity with 47 papers published in the last 6 months.\n\n**Emerging Trends:**\n- Machine learning approaches are increasingly being applied\n- Interdisciplinary collaborations are driving innovation\n- Experimental validation remains critical\n\n**Recommended Next Steps:**\n1. Review the attached papers for foundational knowledge\n2. Consider running a simulation to explore parameter space\n3. Generate specific hypotheses based on identified gaps`;
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="h-[calc(100vh-140px)] flex flex-col">
      {/* Chat Container */}
      <div className="flex-1 glass-card overflow-hidden flex flex-col">
        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-4 md:p-6">
          {messages.length === 0 ? (
            /* Empty State */
            <div className="h-full flex flex-col items-center justify-center">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="text-center mb-8"
              >
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-apeiron-cyan to-apeiron-cyan-dark flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="w-8 h-8 text-black" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">
                  What would you like to research today?
                </h3>
                <p className="text-apeiron-gray text-sm max-w-md">
                  Ask me anything about scientific research. I can help you find papers, 
                  generate hypotheses, and plan experiments.
                </p>
              </motion.div>

              {/* Suggested Queries */}
              <div className="w-full max-w-2xl">
                <p className="text-xs text-apeiron-gray uppercase tracking-wider mb-3 text-center">
                  Try asking
                </p>
                <div className="flex flex-wrap justify-center gap-2">
                  {suggestedQueries.map((query) => (
                    <button
                      key={query}
                      onClick={() => setInputValue(query)}
                      className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-sm text-apeiron-gray hover:text-white transition-colors"
                    >
                      {query}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* Messages */
            <div className="space-y-6 max-w-4xl mx-auto">
              <AnimatePresence>
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className={`flex gap-4 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
                  >
                    {/* Avatar */}
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.role === 'user' 
                        ? 'bg-apeiron-cyan/20' 
                        : 'bg-gradient-to-br from-apeiron-cyan to-apeiron-cyan-dark'
                    }`}>
                      {message.role === 'user' ? (
                        <span className="text-apeiron-cyan text-sm font-medium">U</span>
                      ) : (
                        <img src="/logo.png" alt="AI" className="w-5 h-5" />
                      )}
                    </div>

                    {/* Message Content */}
                    <div className={`flex-1 ${message.role === 'user' ? 'text-right' : ''}`}>
                      <div className={`inline-block text-left max-w-full ${
                        message.role === 'user' 
                          ? 'bg-apeiron-cyan/10 rounded-2xl rounded-tr-sm px-4 py-3' 
                          : ''
                      }`}>
                        {message.role === 'assistant' ? (
                          <div className="prose prose-invert prose-sm max-w-none">
                            {message.content.split('\n').map((line, i) => {
                              if (line.startsWith('**') && line.endsWith('**')) {
                                return <h4 key={i} className="text-white font-semibold mt-4 mb-2">{line.replace(/\*\*/g, '')}</h4>;
                              }
                              if (line.match(/^\d+\./)) {
                                return <p key={i} className="text-apeiron-gray ml-4">{line}</p>;
                              }
                              if (line.startsWith('-')) {
                                return <p key={i} className="text-apeiron-gray ml-4">{line}</p>;
                              }
                              return <p key={i} className="text-apeiron-gray">{line}</p>;
                            })}
                          </div>
                        ) : (
                          <p className="text-white">{message.content}</p>
                        )}

                        {/* Attachments */}
                        {message.attachments && message.attachments.map((attachment) => (
                          <div key={attachment.id} className="mt-4 p-3 bg-white/5 rounded-lg border border-white/10">
                            <div className="flex items-center gap-2 mb-2">
                              <BookOpen className="w-4 h-4 text-apeiron-cyan" />
                              <span className="text-sm font-medium text-white">{attachment.title}</span>
                            </div>
                            <p className="text-xs text-apeiron-gray">{attachment.content}</p>
                            <div className="mt-2 flex gap-2">
                              {mockPapers.slice(0, 3).map((paper) => (
                                <div key={paper.id} className="flex items-center gap-2 px-2 py-1 bg-white/5 rounded text-xs">
                                  <FileText className="w-3 h-3 text-apeiron-gray" />
                                  <span className="text-apeiron-gray truncate max-w-[150px]">{paper.title}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Message Actions */}
                      {message.role === 'assistant' && (
                        <div className="flex items-center gap-2 mt-2">
                          <button className="p-1.5 text-apeiron-gray hover:text-white transition-colors" title="Copy">
                            <Copy className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 text-apeiron-gray hover:text-green-400 transition-colors" title="Helpful">
                            <ThumbsUp className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 text-apeiron-gray hover:text-red-400 transition-colors" title="Not helpful">
                            <ThumbsDown className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 text-apeiron-gray hover:text-white transition-colors" title="Regenerate">
                            <RotateCcw className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>

              {/* Loading Indicator */}
              {isLoading && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex gap-4"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-apeiron-cyan to-apeiron-cyan-dark flex items-center justify-center">
                    <img src="/logo.png" alt="AI" className="w-5 h-5" />
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-apeiron-cyan rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-apeiron-cyan rounded-full animate-bounce animation-delay-100" />
                    <div className="w-2 h-2 bg-apeiron-cyan rounded-full animate-bounce animation-delay-200" />
                  </div>
                </motion.div>
              )}

              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="border-t border-white/5 p-4">
          <div className="max-w-4xl mx-auto">
            {/* Quick Actions */}
            <div className="flex gap-2 mb-3 overflow-x-auto pb-2">
              {quickActions.map((action) => {
                const Icon = action.icon;
                return (
                  <button
                    key={action.label}
                    className="flex items-center gap-2 px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-xs text-apeiron-gray hover:text-white transition-colors whitespace-nowrap"
                  >
                    <Icon className="w-3 h-3" />
                    {action.label}
                  </button>
                );
              })}
            </div>

            {/* Input Field */}
            <div className="flex items-end gap-3 bg-[#111111] border border-white/10 rounded-xl p-3 focus-within:border-apeiron-cyan/50 focus-within:ring-1 focus-within:ring-apeiron-cyan/50 transition-all">
              <button className="p-2 text-apeiron-gray hover:text-white transition-colors">
                <Paperclip className="w-5 h-5" />
              </button>
              <textarea
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask a research question..."
                className="flex-1 bg-transparent text-white placeholder:text-apeiron-gray resize-none outline-none min-h-[24px] max-h-32"
                rows={1}
                style={{ height: 'auto' }}
              />
              <button
                onClick={handleSendMessage}
                disabled={!inputValue.trim() || isLoading}
                className="p-2 bg-apeiron-cyan text-black rounded-lg hover:bg-apeiron-cyan-light transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Send className="w-5 h-5" />
                )}
              </button>
            </div>

            <p className="text-center text-xs text-apeiron-gray mt-2">
              ApeironAI may produce inaccurate information. Verify important information.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
