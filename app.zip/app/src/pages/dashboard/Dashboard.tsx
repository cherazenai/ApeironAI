import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Search, MessageSquare, Lightbulb, BookOpen, Cpu,
  ArrowUpRight, ArrowDownRight, Clock, Sparkles
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';
import { mockDashboardAnalytics, weeklyQueriesData, mockQueries, mockHypotheses } from '@/lib/mockData';

const statCards = [
  { 
    id: 'queries', 
    label: 'Research Queries', 
    value: mockDashboardAnalytics.totalQueries, 
    change: '+12%', 
    trend: 'up',
    icon: MessageSquare,
    color: '#2ab4d9'
  },
  { 
    id: 'hypotheses', 
    label: 'Generated Hypotheses', 
    value: mockDashboardAnalytics.totalHypotheses, 
    change: '+8%', 
    trend: 'up',
    icon: Lightbulb,
    color: '#a2deee'
  },
  { 
    id: 'papers', 
    label: 'Saved Papers', 
    value: mockDashboardAnalytics.totalPapers, 
    change: '+24%', 
    trend: 'up',
    icon: BookOpen,
    color: '#1e86a2'
  },
  { 
    id: 'simulations', 
    label: 'Simulation Runs', 
    value: mockDashboardAnalytics.totalSimulations, 
    change: '+5%', 
    trend: 'up',
    icon: Cpu,
    color: '#135567'
  },
];

const categoryData = [
  { name: 'Chemistry', value: 35, color: '#2ab4d9' },
  { name: 'Energy', value: 25, color: '#1e86a2' },
  { name: 'Medicine', value: 20, color: '#a2deee' },
  { name: 'Climate', value: 15, color: '#135567' },
  { name: 'Other', value: 5, color: '#7d7f83' },
];

export default function Dashboard() {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-6"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">
              Welcome back! <span className="gradient-text">Ready to discover?</span>
            </h2>
            <p className="text-apeiron-gray">
              You have {mockDashboardAnalytics.queriesThisWeek} queries and {mockDashboardAnalytics.hypothesesThisWeek} new hypotheses this week.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-apeiron-gray" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search your research..."
                className="input-field pl-10 w-full md:w-64"
              />
            </div>
            <button className="btn-glow py-2.5 px-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              <span className="hidden sm:inline">New Query</span>
            </button>
          </div>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="glass-card-hover p-5"
            >
              <div className="flex items-start justify-between mb-4">
                <div 
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: `${stat.color}20` }}
                >
                  <Icon className="w-5 h-5" style={{ color: stat.color }} />
                </div>
                <div className={`flex items-center gap-1 text-sm ${
                  stat.trend === 'up' ? 'text-green-400' : 'text-red-400'
                }`}>
                  {stat.trend === 'up' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                  {stat.change}
                </div>
              </div>
              <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
              <p className="text-sm text-apeiron-gray">{stat.label}</p>
            </motion.div>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Activity Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass-card p-6 lg:col-span-2"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-white">Research Activity</h3>
              <p className="text-sm text-apeiron-gray">Queries and hypotheses over time</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-apeiron-cyan" />
                <span className="text-xs text-apeiron-gray">Queries</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-apeiron-cyan-light" />
                <span className="text-xs text-apeiron-gray">Hypotheses</span>
              </div>
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={weeklyQueriesData}>
                <defs>
                  <linearGradient id="colorQueries" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2ab4d9" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#2ab4d9" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorHypotheses" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#a2deee" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#a2deee" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" />
                <XAxis dataKey="day" stroke="#7d7f83" fontSize={12} />
                <YAxis stroke="#7d7f83" fontSize={12} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#0A0A0A', 
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '8px'
                  }}
                  labelStyle={{ color: '#fff' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="queries" 
                  stroke="#2ab4d9" 
                  fillOpacity={1} 
                  fill="url(#colorQueries)" 
                />
                <Area 
                  type="monotone" 
                  dataKey="hypotheses" 
                  stroke="#a2deee" 
                  fillOpacity={1} 
                  fill="url(#colorHypotheses)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Category Distribution */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="glass-card p-6"
        >
          <h3 className="text-lg font-semibold text-white mb-2">Research Categories</h3>
          <p className="text-sm text-apeiron-gray mb-6">Distribution by field</p>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#0A0A0A', 
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '8px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 space-y-2">
            {categoryData.slice(0, 3).map((cat) => (
              <div key={cat.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: cat.color }} />
                  <span className="text-sm text-apeiron-gray">{cat.name}</span>
                </div>
                <span className="text-sm text-white">{cat.value}%</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Recent Activity Row */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent Queries */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="glass-card p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-white">Recent Queries</h3>
            <button className="text-sm text-apeiron-cyan hover:text-apeiron-cyan-light transition-colors">
              View all
            </button>
          </div>
          <div className="space-y-4">
            {mockQueries.slice(0, 3).map((query) => (
              <div key={query.id} className="flex items-start gap-4 p-4 bg-white/5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer">
                <div className="w-8 h-8 rounded-full bg-apeiron-cyan/10 flex items-center justify-center flex-shrink-0">
                  <MessageSquare className="w-4 h-4 text-apeiron-cyan" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-medium truncate">{query.query}</p>
                  <p className="text-apeiron-gray text-xs mt-1 line-clamp-2">{query.response}</p>
                  <div className="flex items-center gap-3 mt-2">
                    <span className="text-xs text-apeiron-gray flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(query.timestamp).toLocaleDateString()}
                    </span>
                    {query.category && (
                      <span className="text-xs bg-apeiron-cyan/10 text-apeiron-cyan px-2 py-0.5 rounded">
                        {query.category}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Recent Hypotheses */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="glass-card p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-white">Recent Hypotheses</h3>
            <button className="text-sm text-apeiron-cyan hover:text-apeiron-cyan-light transition-colors">
              View all
            </button>
          </div>
          <div className="space-y-4">
            {mockHypotheses.slice(0, 3).map((hypothesis) => (
              <div key={hypothesis.id} className="p-4 bg-white/5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium">{hypothesis.topic}</p>
                    <p className="text-apeiron-gray text-xs mt-1 line-clamp-2">{hypothesis.hypothesis}</p>
                  </div>
                  <div className="flex-shrink-0">
                    <div className="relative w-12 h-12">
                      <svg className="w-12 h-12 transform -rotate-90">
                        <circle
                          cx="24"
                          cy="24"
                          r="20"
                          fill="none"
                          stroke="#1a1a1a"
                          strokeWidth="4"
                        />
                        <circle
                          cx="24"
                          cy="24"
                          r="20"
                          fill="none"
                          stroke="#2ab4d9"
                          strokeWidth="4"
                          strokeDasharray={`${hypothesis.confidenceScore * 1.26} 126`}
                          strokeLinecap="round"
                        />
                      </svg>
                      <span className="absolute inset-0 flex items-center justify-center text-xs font-medium text-apeiron-cyan">
                        {hypothesis.confidenceScore}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="glass-card p-6"
      >
        <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'New Research Query', icon: MessageSquare, color: '#2ab4d9' },
            { label: 'Generate Hypothesis', icon: Lightbulb, color: '#a2deee' },
            { label: 'Upload Paper', icon: BookOpen, color: '#1e86a2' },
            { label: 'Run Simulation', icon: Cpu, color: '#135567' },
          ].map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.label}
                className="flex items-center gap-3 p-4 bg-white/5 rounded-lg hover:bg-white/10 transition-colors text-left group"
              >
                <div 
                  className="w-10 h-10 rounded-lg flex items-center justify-center transition-transform group-hover:scale-110"
                  style={{ backgroundColor: `${action.color}20` }}
                >
                  <Icon className="w-5 h-5" style={{ color: action.color }} />
                </div>
                <span className="text-sm text-white font-medium">{action.label}</span>
              </button>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
}
