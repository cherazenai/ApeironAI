import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Lightbulb, Sparkles, Search, BookOpen, TrendingUp, 
  ChevronRight, Loader2, Download, Share2, Copy, Check,
  Beaker, Microscope, Zap
} from 'lucide-react';
import { mockHypotheses, mockPapers } from '@/lib/mockData';
import type { Hypothesis } from '@/types';

const researchAreas = [
  { id: 'materials', label: 'Materials Science', icon: Beaker },
  { id: 'chemistry', label: 'Chemistry', icon: Microscope },
  { id: 'energy', label: 'Energy', icon: Zap },
  { id: 'medicine', label: 'Medicine', icon: TrendingUp },
];

export default function HypothesisGenerator() {
  const [topic, setTopic] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedHypotheses, setGeneratedHypotheses] = useState<Hypothesis[]>([]);
  const [selectedArea, setSelectedArea] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!topic.trim() || isGenerating) return;

    setIsGenerating(true);
    
    // Simulate AI generation
    setTimeout(() => {
      const newHypotheses: Hypothesis[] = [
        {
          id: Date.now().toString(),
          userId: '1',
          topic: topic,
          hypothesis: generateHypothesisText(topic, 1),
          confidenceScore: Math.floor(Math.random() * 30) + 65,
          supportingPapers: mockPapers.slice(0, 2),
          generatedAt: new Date(),
        },
        {
          id: (Date.now() + 1).toString(),
          userId: '1',
          topic: topic,
          hypothesis: generateHypothesisText(topic, 2),
          confidenceScore: Math.floor(Math.random() * 25) + 55,
          supportingPapers: mockPapers.slice(1, 3),
          generatedAt: new Date(),
        },
        {
          id: (Date.now() + 2).toString(),
          userId: '1',
          topic: topic,
          hypothesis: generateHypothesisText(topic, 3),
          confidenceScore: Math.floor(Math.random() * 20) + 45,
          supportingPapers: [mockPapers[0]],
          generatedAt: new Date(),
        },
      ];
      
      setGeneratedHypotheses(newHypotheses);
      setIsGenerating(false);
    }, 3000);
  };

  const generateHypothesisText = (topic: string, variant: number): string => {
    const templates: Record<number, string> = {
      1: `Incorporating ${topic} with a novel interfacial layer will improve performance metrics by 15-20% compared to conventional approaches, based on recent advances in interface engineering.`,
      2: `The synergistic combination of ${topic} with machine learning-guided optimization will reveal previously unexplored parameter spaces, leading to breakthrough performance improvements.`,
      3: `A systematic study of ${topic} under varying conditions will identify optimal processing parameters that maximize efficiency while maintaining stability over extended operation periods.`,
    };
    return templates[variant] || templates[1];
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-6"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1 flex items-center gap-3">
              <Lightbulb className="w-7 h-7 text-apeiron-cyan" />
              Hypothesis Generator
            </h2>
            <p className="text-apeiron-gray">
              Generate novel hypotheses based on cross-disciplinary research and AI reasoning.
            </p>
          </div>
        </div>
      </motion.div>

      {/* Input Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="glass-card p-6"
      >
        {/* Research Areas */}
        <div className="mb-6">
          <label className="block text-sm text-apeiron-gray mb-3">Select Research Area (optional)</label>
          <div className="flex flex-wrap gap-2">
            {researchAreas.map((area) => {
              const Icon = area.icon;
              return (
                <button
                  key={area.id}
                  onClick={() => setSelectedArea(selectedArea === area.id ? null : area.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg border transition-all ${
                    selectedArea === area.id
                      ? 'bg-apeiron-cyan/10 border-apeiron-cyan text-apeiron-cyan'
                      : 'bg-white/5 border-white/10 text-apeiron-gray hover:text-white hover:bg-white/10'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {area.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Topic Input */}
        <div className="mb-4">
          <label className="block text-sm text-apeiron-gray mb-3">Research Topic</label>
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-apeiron-gray" />
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g., perovskite solar cells, lithium-sulfur batteries, drug-protein interactions..."
                className="input-field w-full pl-12 py-4"
                onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
              />
            </div>
            <button
              onClick={handleGenerate}
              disabled={!topic.trim() || isGenerating}
              className="btn-glow flex items-center gap-2 px-6 disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span className="hidden sm:inline">Generating...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  <span className="hidden sm:inline">Generate</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Quick Suggestions */}
        <div className="flex flex-wrap gap-2">
          <span className="text-xs text-apeiron-gray">Try:</span>
          {[
            'solid-state batteries',
            'CO2 reduction catalysts',
            'protein folding prediction',
            'quantum dot solar cells',
          ].map((suggestion) => (
            <button
              key={suggestion}
              onClick={() => setTopic(suggestion)}
              className="text-xs text-apeiron-cyan hover:text-apeiron-cyan-light transition-colors"
            >
              {suggestion}
            </button>
          ))}
        </div>
      </motion.div>

      {/* Generated Hypotheses */}
      <AnimatePresence>
        {generatedHypotheses.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-white">
                Generated Hypotheses
              </h3>
              <span className="text-sm text-apeiron-gray">
                {generatedHypotheses.length} results
              </span>
            </div>

            {generatedHypotheses.map((hypothesis, index) => (
              <motion.div
                key={hypothesis.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="glass-card-hover p-6"
              >
                <div className="flex flex-col lg:flex-row lg:items-start gap-6">
                  {/* Confidence Score */}
                  <div className="flex-shrink-0">
                    <div className="relative w-20 h-20">
                      <svg className="w-20 h-20 transform -rotate-90">
                        <circle
                          cx="40"
                          cy="40"
                          r="36"
                          fill="none"
                          stroke="#1a1a1a"
                          strokeWidth="6"
                        />
                        <circle
                          cx="40"
                          cy="40"
                          r="36"
                          fill="none"
                          stroke={hypothesis.confidenceScore >= 70 ? '#22c55e' : hypothesis.confidenceScore >= 55 ? '#2ab4d9' : '#f59e0b'}
                          strokeWidth="6"
                          strokeDasharray={`${hypothesis.confidenceScore * 2.26} 226`}
                          strokeLinecap="round"
                        />
                      </svg>
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-xl font-bold text-white">{hypothesis.confidenceScore}%</span>
                        <span className="text-xs text-apeiron-gray">confidence</span>
                      </div>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-4 mb-3">
                      <h4 className="text-lg font-medium text-white">
                        Hypothesis {index + 1}
                      </h4>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleCopy(hypothesis.id, hypothesis.hypothesis)}
                          className="p-2 text-apeiron-gray hover:text-white transition-colors"
                          title="Copy"
                        >
                          {copiedId === hypothesis.id ? (
                            <Check className="w-4 h-4 text-green-400" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </button>
                        <button className="p-2 text-apeiron-gray hover:text-white transition-colors" title="Share">
                          <Share2 className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-apeiron-gray hover:text-white transition-colors" title="Download">
                          <Download className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <p className="text-apeiron-gray leading-relaxed mb-4">
                      {hypothesis.hypothesis}
                    </p>

                    {/* Supporting Papers */}
                    {hypothesis.supportingPapers.length > 0 && (
                      <div className="mb-4">
                        <p className="text-xs text-apeiron-gray uppercase tracking-wider mb-2">
                          Supporting Research
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {hypothesis.supportingPapers.map((paper) => (
                            <div
                              key={paper.id}
                              className="flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-lg text-sm"
                            >
                              <BookOpen className="w-4 h-4 text-apeiron-cyan" />
                              <span className="text-apeiron-gray truncate max-w-[200px]">{paper.title}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex flex-wrap gap-3">
                      <button className="flex items-center gap-2 px-4 py-2 bg-apeiron-cyan/10 text-apeiron-cyan rounded-lg hover:bg-apeiron-cyan/20 transition-colors text-sm">
                        <Beaker className="w-4 h-4" />
                        Plan Experiment
                      </button>
                      <button className="flex items-center gap-2 px-4 py-2 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors text-sm">
                        <Microscope className="w-4 h-4" />
                        Run Simulation
                      </button>
                      <button className="flex items-center gap-2 px-4 py-2 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors text-sm">
                        <BookOpen className="w-4 h-4" />
                        Find More Papers
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Previous Hypotheses */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="glass-card p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-white">Previous Hypotheses</h3>
          <button className="text-sm text-apeiron-cyan hover:text-apeiron-cyan-light transition-colors">
            View all
          </button>
        </div>

        <div className="space-y-3">
          {mockHypotheses.map((hypothesis) => (
            <div
              key={hypothesis.id}
              className="flex items-center gap-4 p-4 bg-white/5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            >
              <div className="w-10 h-10 rounded-lg bg-apeiron-cyan/10 flex items-center justify-center flex-shrink-0">
                <Lightbulb className="w-5 h-5 text-apeiron-cyan" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white font-medium truncate">{hypothesis.topic}</p>
                <p className="text-sm text-apeiron-gray truncate">{hypothesis.hypothesis}</p>
              </div>
              <div className="flex items-center gap-3 flex-shrink-0">
                <span className={`text-sm font-medium ${
                  hypothesis.confidenceScore >= 70 ? 'text-green-400' : 
                  hypothesis.confidenceScore >= 55 ? 'text-apeiron-cyan' : 'text-yellow-400'
                }`}>
                  {hypothesis.confidenceScore}%
                </span>
                <ChevronRight className="w-5 h-5 text-apeiron-gray" />
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
