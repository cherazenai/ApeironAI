import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  User, Mail, Building2, MapPin, Link as LinkIcon, Calendar,
  Edit3, Camera, Check, Copy, Award, BookOpen, Lightbulb, Cpu
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { mockDashboardAnalytics } from '@/lib/mockData';

export default function Profile() {
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopyId = () => {
    navigator.clipboard.writeText(user?.id || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const stats = [
    { label: 'Queries', value: mockDashboardAnalytics.totalQueries, icon: BookOpen },
    { label: 'Hypotheses', value: mockDashboardAnalytics.totalHypotheses, icon: Lightbulb },
    { label: 'Simulations', value: mockDashboardAnalytics.totalSimulations, icon: Cpu },
  ];

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-6"
      >
        <div className="flex flex-col md:flex-row items-start gap-6">
          {/* Avatar */}
          <div className="relative">
            <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-apeiron-cyan to-apeiron-cyan-dark flex items-center justify-center">
              <span className="text-4xl font-bold text-black">
                {user?.name?.charAt(0).toUpperCase()}
              </span>
            </div>
            <button className="absolute -bottom-2 -right-2 w-8 h-8 bg-[#111111] border border-white/10 rounded-full flex items-center justify-center text-apeiron-gray hover:text-white transition-colors">
              <Camera className="w-4 h-4" />
            </button>
          </div>

          {/* Info */}
          <div className="flex-1">
            <div className="flex flex-col md:flex-row md:items-center gap-4 mb-4">
              <div>
                <h2 className="text-2xl font-bold text-white">{user?.name}</h2>
                <p className="text-apeiron-gray">{user?.email}</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="px-3 py-1 bg-apeiron-cyan/10 text-apeiron-cyan text-sm rounded-full capitalize">
                  {user?.plan} Plan
                </span>
                <span className="px-3 py-1 bg-white/5 text-apeiron-gray text-sm rounded-full capitalize">
                  {user?.role}
                </span>
              </div>
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="md:ml-auto flex items-center gap-2 px-4 py-2 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors text-sm"
              >
                <Edit3 className="w-4 h-4" />
                Edit Profile
              </button>
            </div>

            {/* User ID */}
            <div className="flex items-center gap-2 text-sm">
              <span className="text-apeiron-gray">User ID:</span>
              <code className="bg-white/5 px-2 py-1 rounded text-apeiron-cyan">{user?.id}</code>
              <button
                onClick={handleCopyId}
                className="p-1 text-apeiron-gray hover:text-white transition-colors"
              >
                {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid md:grid-cols-3 gap-4"
      >
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="glass-card p-5 text-center">
              <div className="w-12 h-12 rounded-xl bg-apeiron-cyan/10 flex items-center justify-center mx-auto mb-3">
                <Icon className="w-6 h-6 text-apeiron-cyan" />
              </div>
              <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
              <p className="text-sm text-apeiron-gray">{stat.label}</p>
            </div>
          );
        })}
      </motion.div>

      {/* Profile Details */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="glass-card p-6"
      >
        <h3 className="text-lg font-semibold text-white mb-6">Profile Information</h3>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm text-apeiron-gray mb-2">Full Name</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-apeiron-gray" />
              <input
                type="text"
                defaultValue={user?.name}
                disabled={!isEditing}
                className="input-field w-full pl-12 disabled:opacity-50"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm text-apeiron-gray mb-2">Email</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-apeiron-gray" />
              <input
                type="email"
                defaultValue={user?.email}
                disabled={!isEditing}
                className="input-field w-full pl-12 disabled:opacity-50"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm text-apeiron-gray mb-2">Organization</label>
            <div className="relative">
              <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-apeiron-gray" />
              <input
                type="text"
                placeholder="Add organization"
                disabled={!isEditing}
                className="input-field w-full pl-12 disabled:opacity-50"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm text-apeiron-gray mb-2">Location</label>
            <div className="relative">
              <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-apeiron-gray" />
              <input
                type="text"
                placeholder="Add location"
                disabled={!isEditing}
                className="input-field w-full pl-12 disabled:opacity-50"
              />
            </div>
          </div>

          <div className="md:col-span-2">
            <label className="block text-sm text-apeiron-gray mb-2">Website</label>
            <div className="relative">
              <LinkIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-apeiron-gray" />
              <input
                type="url"
                placeholder="Add website"
                disabled={!isEditing}
                className="input-field w-full pl-12 disabled:opacity-50"
              />
            </div>
          </div>

          <div className="md:col-span-2">
            <label className="block text-sm text-apeiron-gray mb-2">Bio</label>
            <textarea
              placeholder="Tell us about yourself..."
              disabled={!isEditing}
              className="input-field w-full h-32 resize-none disabled:opacity-50"
            />
          </div>
        </div>

        {isEditing && (
          <div className="flex gap-3 mt-6">
            <button
              onClick={() => setIsEditing(false)}
              className="flex-1 py-3 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={() => setIsEditing(false)}
              className="btn-glow flex-1"
            >
              Save Changes
            </button>
          </div>
        )}
      </motion.div>

      {/* Account Info */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="glass-card p-6"
      >
        <h3 className="text-lg font-semibold text-white mb-6">Account Information</h3>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between py-3 border-b border-white/5">
            <div>
              <p className="text-white">Member Since</p>
              <p className="text-sm text-apeiron-gray">{user?.createdAt?.toLocaleDateString()}</p>
            </div>
            <Calendar className="w-5 h-5 text-apeiron-gray" />
          </div>

          <div className="flex items-center justify-between py-3 border-b border-white/5">
            <div>
              <p className="text-white">Plan</p>
              <p className="text-sm text-apeiron-gray capitalize">{user?.plan}</p>
            </div>
            <Award className="w-5 h-5 text-apeiron-cyan" />
          </div>

          <div className="flex items-center justify-between py-3">
            <div>
              <p className="text-white">Role</p>
              <p className="text-sm text-apeiron-gray capitalize">{user?.role}</p>
            </div>
            <User className="w-5 h-5 text-apeiron-gray" />
          </div>
        </div>
      </motion.div>
    </div>
  );
}
