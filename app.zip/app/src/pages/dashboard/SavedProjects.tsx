import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  FolderOpen, Plus, Edit3, Trash2,
  Lightbulb, BookOpen, Cpu, FlaskConical, Clock, ChevronRight
} from 'lucide-react';
import { mockProjects } from '@/lib/mockData';

export default function SavedProjects() {
  const [projects] = useState(mockProjects);
  const [, setIsNewModalOpen] = useState(false);

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-6"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1 flex items-center gap-3">
              <FolderOpen className="w-7 h-7 text-apeiron-cyan" />
              Saved Projects
            </h2>
            <p className="text-apeiron-gray">
              Organize your research into projects.
            </p>
          </div>
          <button
            onClick={() => setIsNewModalOpen(true)}
            className="btn-glow flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            New Project
          </button>
        </div>
      </motion.div>

      {/* Projects Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid md:grid-cols-2 gap-4"
      >
        {projects.map((project, index) => (
          <motion.div
            key={project.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 + index * 0.05 }}
            className="glass-card-hover p-6 group cursor-pointer"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-apeiron-cyan/10 flex items-center justify-center">
                <FolderOpen className="w-6 h-6 text-apeiron-cyan" />
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="p-2 text-apeiron-gray hover:text-white transition-colors">
                  <Edit3 className="w-4 h-4" />
                </button>
                <button className="p-2 text-apeiron-gray hover:text-red-400 transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-apeiron-cyan transition-colors">
              {project.name}
            </h3>
            <p className="text-sm text-apeiron-gray mb-4 line-clamp-2">
              {project.description}
            </p>

            {/* Stats */}
            <div className="flex items-center gap-4 mb-4">
              <div className="flex items-center gap-1.5 text-xs text-apeiron-gray">
                <Lightbulb className="w-3.5 h-3.5" />
                {project.hypotheses.length}
              </div>
              <div className="flex items-center gap-1.5 text-xs text-apeiron-gray">
                <BookOpen className="w-3.5 h-3.5" />
                {project.papers.length}
              </div>
              <div className="flex items-center gap-1.5 text-xs text-apeiron-gray">
                <Cpu className="w-3.5 h-3.5" />
                {project.simulations.length}
              </div>
              <div className="flex items-center gap-1.5 text-xs text-apeiron-gray">
                <FlaskConical className="w-3.5 h-3.5" />
                {project.experiments.length}
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between pt-4 border-t border-white/5">
              <span className="text-xs text-apeiron-gray flex items-center gap-1">
                <Clock className="w-3 h-3" />
                Updated {new Date(project.updatedAt).toLocaleDateString()}
              </span>
              <ChevronRight className="w-5 h-5 text-apeiron-gray group-hover:text-apeiron-cyan transition-colors" />
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* Empty State */}
      {projects.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16"
        >
          <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mx-auto mb-4">
            <FolderOpen className="w-8 h-8 text-apeiron-gray" />
          </div>
          <h3 className="text-lg font-medium text-white mb-2">No projects yet</h3>
          <p className="text-apeiron-gray text-sm mb-4">
            Create your first project to organize your research.
          </p>
          <button
            onClick={() => setIsNewModalOpen(true)}
            className="btn-outline-glow"
          >
            Create Project
          </button>
        </motion.div>
      )}
    </div>
  );
}
