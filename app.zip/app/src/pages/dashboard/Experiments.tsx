import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FlaskConical, Plus, CheckCircle2, Edit3, Trash2, Play,
  Lightbulb, ChevronDown
} from 'lucide-react';
import { mockExperiments } from '@/lib/mockData';
import type { Experiment } from '@/types';

const statusConfig = {
  planned: { color: '#f59e0b', bgColor: '#f59e0b20', label: 'Planned' },
  'in-progress': { color: '#2ab4d9', bgColor: '#2ab4d920', label: 'In Progress' },
  completed: { color: '#22c55e', bgColor: '#22c55e20', label: 'Completed' },
};

export default function Experiments() {
  const [experiments, setExperiments] = useState<Experiment[]>(mockExperiments);
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [expandedExperiment, setExpandedExperiment] = useState<string | null>(null);

  const toggleStep = (experimentId: string, stepId: string) => {
    setExperiments(experiments.map(exp => {
      if (exp.id === experimentId) {
        const updatedSteps = exp.steps.map(step =>
          step.id === stepId ? { ...step, completed: !step.completed } : step
        );
        const allCompleted = updatedSteps.every(s => s.completed);
        return {
          ...exp,
          steps: updatedSteps,
          status: allCompleted ? 'completed' : exp.status,
        };
      }
      return exp;
    }));
  };

  const progressPercentage = (experiment: Experiment) => {
    return Math.round((experiment.steps.filter(s => s.completed).length / experiment.steps.length) * 100);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-6"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1 flex items-center gap-3">
              <FlaskConical className="w-7 h-7 text-apeiron-cyan" />
              Experiments
            </h2>
            <p className="text-apeiron-gray">
              Plan and track your experimental workflows.
            </p>
          </div>
          <button
            onClick={() => setIsNewModalOpen(true)}
            className="btn-glow flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            New Experiment
          </button>
        </div>
      </motion.div>

      {/* Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-3 gap-4"
      >
        {[
          { label: 'Planned', value: experiments.filter(e => e.status === 'planned').length, color: '#f59e0b' },
          { label: 'In Progress', value: experiments.filter(e => e.status === 'in-progress').length, color: '#2ab4d9' },
          { label: 'Completed', value: experiments.filter(e => e.status === 'completed').length, color: '#22c55e' },
        ].map((stat) => (
          <div key={stat.label} className="glass-card p-4 text-center">
            <p className="text-2xl font-bold mb-1" style={{ color: stat.color }}>{stat.value}</p>
            <p className="text-sm text-apeiron-gray">{stat.label}</p>
          </div>
        ))}
      </motion.div>

      {/* Experiments List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="space-y-4"
      >
        {experiments.map((experiment, index) => {
          const status = statusConfig[experiment.status];
          const isExpanded = expandedExperiment === experiment.id;
          const progress = progressPercentage(experiment);
          
          return (
            <motion.div
              key={experiment.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25 + index * 0.05 }}
              className="glass-card-hover overflow-hidden"
            >
              {/* Header */}
              <div 
                className="p-5 cursor-pointer"
                onClick={() => setExpandedExperiment(isExpanded ? null : experiment.id)}
              >
                <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                  {/* Icon */}
                  <div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: status.bgColor }}
                  >
                    <FlaskConical className="w-6 h-6" style={{ color: status.color }} />
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="text-lg font-medium text-white">{experiment.title}</h3>
                      <span 
                        className="px-2 py-0.5 text-xs rounded-full"
                        style={{ backgroundColor: status.bgColor, color: status.color }}
                      >
                        {status.label}
                      </span>
                    </div>
                    <p className="text-sm text-apeiron-gray line-clamp-1">{experiment.description}</p>
                    
                    {/* Progress Bar */}
                    <div className="mt-3">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-apeiron-gray">Progress</span>
                        <span className="text-white">{progress}%</span>
                      </div>
                      <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${progress}%` }}
                          className="h-full rounded-full"
                          style={{ backgroundColor: status.color }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Meta */}
                  <div className="flex items-center gap-4 flex-shrink-0">
                    <div className="text-right">
                      <p className="text-xs text-apeiron-gray">
                        {experiment.steps.filter(s => s.completed).length} / {experiment.steps.length} steps
                      </p>
                      <p className="text-xs text-apeiron-gray">
                        {new Date(experiment.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <ChevronDown 
                      className={`w-5 h-5 text-apeiron-gray transition-transform ${isExpanded ? 'rotate-180' : ''}`}
                    />
                  </div>
                </div>
              </div>

              {/* Expanded Content */}
              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: 'auto' }}
                    exit={{ height: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="px-5 pb-5 border-t border-white/5">
                      <div className="pt-4 space-y-2">
                        {experiment.steps.map((step) => (
                          <div
                            key={step.id}
                            onClick={() => toggleStep(experiment.id, step.id)}
                            className="flex items-start gap-3 p-3 bg-white/5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer group"
                          >
                            <div className={`mt-0.5 w-5 h-5 rounded border flex items-center justify-center transition-colors ${
                              step.completed 
                                ? 'bg-apeiron-cyan border-apeiron-cyan' 
                                : 'border-apeiron-gray group-hover:border-apeiron-cyan'
                            }`}>
                              {step.completed && <CheckCircle2 className="w-3 h-3 text-black" />}
                            </div>
                            <div className="flex-1">
                              <p className={`text-sm ${step.completed ? 'text-apeiron-gray line-through' : 'text-white'}`}>
                                Step {step.order}: {step.description}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Actions */}
                      <div className="flex gap-3 mt-4">
                        <button
                          className="flex items-center gap-2 px-4 py-2 bg-apeiron-cyan/10 text-apeiron-cyan rounded-lg hover:bg-apeiron-cyan/20 transition-colors text-sm"
                        >
                          <Edit3 className="w-4 h-4" />
                          Edit
                        </button>
                        <button className="flex items-center gap-2 px-4 py-2 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors text-sm">
                          <Play className="w-4 h-4" />
                          Start
                        </button>
                        <button className="flex items-center gap-2 px-4 py-2 bg-white/5 text-red-400 rounded-lg hover:bg-red-500/10 transition-colors text-sm ml-auto">
                          <Trash2 className="w-4 h-4" />
                          Delete
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}
      </motion.div>

      {/* New Experiment Modal */}
      <AnimatePresence>
        {isNewModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setIsNewModalOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-card w-full max-lg max-h-[80vh] overflow-y-auto"
            >
              <div className="p-6">
                <h3 className="text-xl font-semibold text-white mb-6">New Experiment</h3>

                {/* Title */}
                <div className="mb-4">
                  <label className="block text-sm text-apeiron-gray mb-2">Experiment Title</label>
                  <input
                    type="text"
                    className="input-field w-full"
                    placeholder="e.g., Battery Cycling Test"
                  />
                </div>

                {/* Description */}
                <div className="mb-4">
                  <label className="block text-sm text-apeiron-gray mb-2">Description</label>
                  <textarea
                    className="input-field w-full h-24 resize-none"
                    placeholder="Describe the purpose of this experiment..."
                  />
                </div>

                {/* Linked Hypothesis */}
                <div className="mb-6">
                  <label className="block text-sm text-apeiron-gray mb-2">Linked Hypothesis (optional)</label>
                  <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                    <Lightbulb className="w-5 h-5 text-apeiron-cyan" />
                    <span className="text-sm text-apeiron-gray">Select a hypothesis...</span>
                    <ChevronDown className="w-4 h-4 text-apeiron-gray ml-auto" />
                  </div>
                </div>

                {/* Steps */}
                <div className="mb-6">
                  <label className="block text-sm text-apeiron-gray mb-3">Experiment Steps</label>
                  <div className="space-y-2">
                    {['Prepare materials', 'Set up equipment', 'Run test', 'Analyze results'].map((step, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <span className="w-6 h-6 rounded-full bg-apeiron-cyan/10 text-apeiron-cyan text-xs flex items-center justify-center flex-shrink-0">
                          {i + 1}
                        </span>
                        <input
                          type="text"
                          className="input-field flex-1"
                          placeholder={`Step ${i + 1}`}
                          defaultValue={step}
                        />
                      </div>
                    ))}
                  </div>
                  <button className="mt-3 text-sm text-apeiron-cyan hover:text-apeiron-cyan-light transition-colors flex items-center gap-1">
                    <Plus className="w-4 h-4" />
                    Add Step
                  </button>
                </div>

                {/* Actions */}
                <div className="flex gap-3">
                  <button
                    onClick={() => setIsNewModalOpen(false)}
                    className="flex-1 py-3 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => setIsNewModalOpen(false)}
                    className="btn-glow flex-1"
                  >
                    Create Experiment
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
