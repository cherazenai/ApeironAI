import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search, Upload, FileText, Tag, Download,
  ExternalLink, Trash2, Grid, List, X,
  ChevronDown, Sparkles, Clock, User
} from 'lucide-react';
import { mockPapers } from '@/lib/mockData';
import type { Paper } from '@/types';

const tags = ['All', 'Battery', 'Catalysis', 'Materials', 'AI/ML', 'Climate', 'Medicine'];

const sortOptions = [
  { label: 'Recently Added', value: 'recent' },
  { label: 'Title A-Z', value: 'title' },
  { label: 'Author', value: 'author' },
];

export default function PaperLibrary() {
  const [papers, setPapers] = useState<Paper[]>(mockPapers);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState('All');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [sortBy, setSortBy] = useState('recent');
  const [selectedPaper, setSelectedPaper] = useState<Paper | null>(null);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);

  const filteredPapers = papers.filter((paper) => {
    const matchesSearch = 
      paper.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      paper.authors.some(a => a.toLowerCase().includes(searchQuery.toLowerCase())) ||
      paper.abstract.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesTag = selectedTag === 'All' || paper.tags.includes(selectedTag.toLowerCase());
    
    return matchesSearch && matchesTag;
  });

  const handleDelete = (id: string) => {
    setPapers(papers.filter(p => p.id !== id));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-6"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1 flex items-center gap-3">
              <FileText className="w-7 h-7 text-apeiron-cyan" />
              Paper Library
            </h2>
            <p className="text-apeiron-gray">
              Manage your research papers, summaries, and tags.
            </p>
          </div>
          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="btn-glow flex items-center gap-2"
          >
            <Upload className="w-4 h-4" />
            Upload Paper
          </button>
        </div>
      </motion.div>

      {/* Filters and Search */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="flex flex-col lg:flex-row gap-4"
      >
        {/* Search */}
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-apeiron-gray" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search papers by title, author, or content..."
            className="input-field w-full pl-12 py-3"
          />
        </div>

        {/* View Toggle */}
        <div className="flex items-center gap-2 bg-white/5 rounded-lg p-1">
          <button
            onClick={() => setViewMode('list')}
            className={`p-2 rounded-md transition-colors ${
              viewMode === 'list' ? 'bg-apeiron-cyan/20 text-apeiron-cyan' : 'text-apeiron-gray hover:text-white'
            }`}
          >
            <List className="w-5 h-5" />
          </button>
          <button
            onClick={() => setViewMode('grid')}
            className={`p-2 rounded-md transition-colors ${
              viewMode === 'grid' ? 'bg-apeiron-cyan/20 text-apeiron-cyan' : 'text-apeiron-gray hover:text-white'
            }`}
          >
            <Grid className="w-5 h-5" />
          </button>
        </div>

        {/* Sort */}
        <div className="relative">
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="input-field py-3 pr-10 appearance-none cursor-pointer"
          >
            {sortOptions.map((opt) => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-apeiron-gray pointer-events-none" />
        </div>
      </motion.div>

      {/* Tags */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="flex flex-wrap gap-2"
      >
        {tags.map((tag) => (
          <button
            key={tag}
            onClick={() => setSelectedTag(tag)}
            className={`px-4 py-2 rounded-full text-sm transition-all ${
              selectedTag === tag
                ? 'bg-apeiron-cyan text-black font-medium'
                : 'bg-white/5 text-apeiron-gray hover:text-white hover:bg-white/10'
            }`}
          >
            {tag}
          </button>
        ))}
      </motion.div>

      {/* Results Count */}
      <div className="flex items-center justify-between">
        <p className="text-apeiron-gray text-sm">
          {filteredPapers.length} paper{filteredPapers.length !== 1 ? 's' : ''} found
        </p>
      </div>

      {/* Papers List/Grid */}
      <AnimatePresence mode="wait">
        {viewMode === 'list' ? (
          <motion.div
            key="list"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-3"
          >
            {filteredPapers.map((paper, index) => (
              <motion.div
                key={paper.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="glass-card-hover p-5"
              >
                <div className="flex flex-col lg:flex-row lg:items-start gap-4">
                  {/* Icon */}
                  <div className="w-12 h-12 rounded-xl bg-apeiron-cyan/10 flex items-center justify-center flex-shrink-0">
                    <FileText className="w-6 h-6 text-apeiron-cyan" />
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-semibold text-white mb-1 hover:text-apeiron-cyan transition-colors cursor-pointer">
                      {paper.title}
                    </h3>
                    <p className="text-sm text-apeiron-gray mb-2">
                      {paper.authors.join(', ')}
                    </p>
                    <p className="text-sm text-apeiron-gray line-clamp-2 mb-3">
                      {paper.abstract}
                    </p>

                    {/* Tags and Meta */}
                    <div className="flex flex-wrap items-center gap-3">
                      {paper.tags.map((tag) => (
                        <span
                          key={tag}
                          className="px-2 py-1 bg-white/5 text-apeiron-gray text-xs rounded-full flex items-center gap-1"
                        >
                          <Tag className="w-3 h-3" />
                          {tag}
                        </span>
                      ))}
                      <span className="text-xs text-apeiron-gray flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(paper.uploadedAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex lg:flex-col items-center gap-2">
                    <button
                      onClick={() => setSelectedPaper(paper)}
                      className="p-2 text-apeiron-gray hover:text-white transition-colors"
                      title="View"
                    >
                      <ExternalLink className="w-5 h-5" />
                    </button>
                    <button
                      className="p-2 text-apeiron-gray hover:text-white transition-colors"
                      title="Download"
                    >
                      <Download className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(paper.id)}
                      className="p-2 text-apeiron-gray hover:text-red-400 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <motion.div
            key="grid"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            {filteredPapers.map((paper, index) => (
              <motion.div
                key={paper.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="glass-card-hover p-5 flex flex-col"
              >
                <div className="w-12 h-12 rounded-xl bg-apeiron-cyan/10 flex items-center justify-center mb-4">
                  <FileText className="w-6 h-6 text-apeiron-cyan" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2 line-clamp-2 hover:text-apeiron-cyan transition-colors cursor-pointer">
                  {paper.title}
                </h3>
                <p className="text-sm text-apeiron-gray mb-3 line-clamp-1">
                  {paper.authors.join(', ')}
                </p>
                <p className="text-sm text-apeiron-gray line-clamp-3 mb-4 flex-1">
                  {paper.abstract}
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {paper.tags.slice(0, 3).map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-1 bg-white/5 text-apeiron-gray text-xs rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="flex items-center justify-between pt-4 border-t border-white/5">
                  <span className="text-xs text-apeiron-gray">
                    {new Date(paper.uploadedAt).toLocaleDateString()}
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setSelectedPaper(paper)}
                      className="p-2 text-apeiron-gray hover:text-white transition-colors"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-apeiron-gray hover:text-white transition-colors">
                      <Download className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Empty State */}
      {filteredPapers.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-16"
        >
          <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mx-auto mb-4">
            <FileText className="w-8 h-8 text-apeiron-gray" />
          </div>
          <h3 className="text-lg font-medium text-white mb-2">No papers found</h3>
          <p className="text-apeiron-gray text-sm mb-4">
            Try adjusting your search or upload a new paper.
          </p>
          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="btn-outline-glow"
          >
            Upload Paper
          </button>
        </motion.div>
      )}

      {/* Paper Detail Modal */}
      <AnimatePresence>
        {selectedPaper && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedPaper(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-card w-full max-w-2xl max-h-[80vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-apeiron-cyan/10 flex items-center justify-center">
                    <FileText className="w-6 h-6 text-apeiron-cyan" />
                  </div>
                  <button
                    onClick={() => setSelectedPaper(null)}
                    className="p-2 text-apeiron-gray hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <h2 className="text-xl font-semibold text-white mb-2">{selectedPaper.title}</h2>
                <p className="text-sm text-apeiron-gray mb-4">
                  <User className="w-4 h-4 inline mr-1" />
                  {selectedPaper.authors.join(', ')}
                </p>

                <div className="flex flex-wrap gap-2 mb-6">
                  {selectedPaper.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1 bg-apeiron-cyan/10 text-apeiron-cyan text-sm rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-white mb-2">Abstract</h4>
                    <p className="text-sm text-apeiron-gray leading-relaxed">{selectedPaper.abstract}</p>
                  </div>

                  {selectedPaper.summary && (
                    <div className="p-4 bg-apeiron-cyan/5 rounded-lg border border-apeiron-cyan/20">
                      <div className="flex items-center gap-2 mb-2">
                        <Sparkles className="w-4 h-4 text-apeiron-cyan" />
                        <h4 className="text-sm font-medium text-apeiron-cyan">AI Summary</h4>
                      </div>
                      <p className="text-sm text-apeiron-gray">{selectedPaper.summary}</p>
                    </div>
                  )}
                </div>

                <div className="flex gap-3 mt-6 pt-6 border-t border-white/5">
                  <button className="btn-glow flex-1 flex items-center justify-center gap-2">
                    <Download className="w-4 h-4" />
                    Download
                  </button>
                  <button className="btn-outline-glow flex-1 flex items-center justify-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    Summarize
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Upload Modal */}
      <AnimatePresence>
        {isUploadModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setIsUploadModalOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-card w-full max-w-md"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-white">Upload Paper</h3>
                  <button
                    onClick={() => setIsUploadModalOpen(false)}
                    className="p-2 text-apeiron-gray hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="border-2 border-dashed border-white/10 rounded-xl p-8 text-center hover:border-apeiron-cyan/30 transition-colors cursor-pointer">
                  <Upload className="w-12 h-12 text-apeiron-gray mx-auto mb-4" />
                  <p className="text-white font-medium mb-2">Drop your paper here</p>
                  <p className="text-sm text-apeiron-gray mb-4">or click to browse</p>
                  <p className="text-xs text-apeiron-gray">Supports PDF, DOCX up to 50MB</p>
                </div>

                <div className="mt-6 space-y-4">
                  <div>
                    <label className="block text-sm text-apeiron-gray mb-2">Title</label>
                    <input type="text" className="input-field w-full" placeholder="Paper title" />
                  </div>
                  <div>
                    <label className="block text-sm text-apeiron-gray mb-2">Authors</label>
                    <input type="text" className="input-field w-full" placeholder="Author names, comma separated" />
                  </div>
                  <div>
                    <label className="block text-sm text-apeiron-gray mb-2">Tags</label>
                    <input type="text" className="input-field w-full" placeholder="Add tags..." />
                  </div>
                </div>

                <div className="flex gap-3 mt-6">
                  <button
                    onClick={() => setIsUploadModalOpen(false)}
                    className="flex-1 py-3 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => setIsUploadModalOpen(false)}
                    className="btn-glow flex-1"
                  >
                    Upload
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
