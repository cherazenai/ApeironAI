import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Settings2, Bell, Shield, Eye, Moon, Globe,
  Smartphone, Mail, ChevronRight, Check, AlertTriangle
} from 'lucide-react';

const notificationSettings = [
  { id: 'email-research', label: 'Research Updates', description: 'Get notified about new research findings', default: true },
  { id: 'email-hypothesis', label: 'Hypothesis Generated', description: 'When AI generates new hypotheses', default: true },
  { id: 'email-simulation', label: 'Simulation Complete', description: 'When your simulations finish running', default: true },
  { id: 'email-marketing', label: 'Product Updates', description: 'News about features and improvements', default: false },
];

const securitySettings = [
  { id: '2fa', label: 'Two-Factor Authentication', description: 'Add an extra layer of security', enabled: false },
  { id: 'sessions', label: 'Active Sessions', description: 'Manage your active login sessions', enabled: true },
  { id: 'api', label: 'API Keys', description: 'Manage your API access keys', enabled: true },
];

export default function Settings() {
  const [activeTab, setActiveTab] = useState('general');
  const [notifications, setNotifications] = useState<Record<string, boolean>>({
    'email-research': true,
    'email-hypothesis': true,
    'email-simulation': true,
    'email-marketing': false,
  });

  const tabs = [
    { id: 'general', label: 'General', icon: Settings2 },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'appearance', label: 'Appearance', icon: Eye },
  ];

  const toggleNotification = (id: string) => {
    setNotifications(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-6"
      >
        <h2 className="text-2xl font-bold text-white mb-1 flex items-center gap-3">
          <Settings2 className="w-7 h-7 text-apeiron-cyan" />
          Settings
        </h2>
        <p className="text-apeiron-gray">
          Manage your account preferences and settings.
        </p>
      </motion.div>

      <div className="grid lg:grid-cols-4 gap-6">
        {/* Sidebar Tabs */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="lg:col-span-1"
        >
          <div className="glass-card p-2 space-y-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                    activeTab === tab.id
                      ? 'bg-apeiron-cyan/10 text-apeiron-cyan'
                      : 'text-apeiron-gray hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-sm font-medium">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </motion.div>

        {/* Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-3"
        >
          {/* General Settings */}
          {activeTab === 'general' && (
            <div className="space-y-4">
              <div className="glass-card p-6">
                <h3 className="text-lg font-semibold text-white mb-6">General Preferences</h3>
                
                <div className="space-y-6">
                  <div className="flex items-center justify-between py-3 border-b border-white/5">
                    <div>
                      <p className="text-white">Language</p>
                      <p className="text-sm text-apeiron-gray">Choose your preferred language</p>
                    </div>
                    <div className="flex items-center gap-2 text-apeiron-gray">
                      <Globe className="w-4 h-4" />
                      <span>English</span>
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  </div>

                  <div className="flex items-center justify-between py-3 border-b border-white/5">
                    <div>
                      <p className="text-white">Time Zone</p>
                      <p className="text-sm text-apeiron-gray">Set your local time zone</p>
                    </div>
                    <div className="flex items-center gap-2 text-apeiron-gray">
                      <span>UTC-5 (EST)</span>
                      <ChevronRight className="w-4 h-4" />
                    </div>
                  </div>

                  <div className="flex items-center justify-between py-3">
                    <div>
                      <p className="text-white">Auto-save</p>
                      <p className="text-sm text-apeiron-gray">Automatically save your work</p>
                    </div>
                    <div className="w-12 h-6 bg-apeiron-cyan rounded-full relative cursor-pointer">
                      <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full" />
                    </div>
                  </div>
                </div>
              </div>

              <div className="glass-card p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Data & Privacy</h3>
                <p className="text-sm text-apeiron-gray mb-4">
                  Control how your data is used and stored.
                </p>
                <div className="flex gap-3">
                  <button className="px-4 py-2 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors text-sm">
                    Export Data
                  </button>
                  <button className="px-4 py-2 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500/20 transition-colors text-sm">
                    Delete Account
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Notifications */}
          {activeTab === 'notifications' && (
            <div className="glass-card p-6">
              <h3 className="text-lg font-semibold text-white mb-6">Email Notifications</h3>
              
              <div className="space-y-4">
                {notificationSettings.map((setting) => (
                  <div
                    key={setting.id}
                    className="flex items-center justify-between py-4 border-b border-white/5 last:border-0"
                  >
                    <div>
                      <p className="text-white">{setting.label}</p>
                      <p className="text-sm text-apeiron-gray">{setting.description}</p>
                    </div>
                    <button
                      onClick={() => toggleNotification(setting.id)}
                      className={`w-12 h-6 rounded-full relative transition-colors ${
                        notifications[setting.id] ? 'bg-apeiron-cyan' : 'bg-white/20'
                      }`}
                    >
                      <div
                        className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${
                          notifications[setting.id] ? 'left-7' : 'left-1'
                        }`}
                      />
                    </button>
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-6 border-t border-white/5">
                <h4 className="text-white font-medium mb-4">Push Notifications</h4>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                    <Smartphone className="w-5 h-5 text-apeiron-gray" />
                    <span className="text-sm text-apeiron-gray">Mobile</span>
                    <Check className="w-4 h-4 text-green-400" />
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                    <Mail className="w-5 h-5 text-apeiron-gray" />
                    <span className="text-sm text-apeiron-gray">Email</span>
                    <Check className="w-4 h-4 text-green-400" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Security */}
          {activeTab === 'security' && (
            <div className="space-y-4">
              <div className="glass-card p-6">
                <h3 className="text-lg font-semibold text-white mb-6">Security Settings</h3>
                
                <div className="space-y-4">
                  {securitySettings.map((setting) => (
                    <div
                      key={setting.id}
                      className="flex items-center justify-between py-4 border-b border-white/5 last:border-0"
                    >
                      <div>
                        <p className="text-white">{setting.label}</p>
                        <p className="text-sm text-apeiron-gray">{setting.description}</p>
                      </div>
                      <button className="px-4 py-2 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors text-sm">
                        Configure
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="glass-card p-6 border-red-500/20">
                <div className="flex items-start gap-4">
                  <AlertTriangle className="w-6 h-6 text-red-400 flex-shrink-0" />
                  <div>
                    <h4 className="text-white font-medium mb-1">Danger Zone</h4>
                    <p className="text-sm text-apeiron-gray mb-4">
                      These actions are irreversible. Please proceed with caution.
                    </p>
                    <div className="flex gap-3">
                      <button className="px-4 py-2 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500/20 transition-colors text-sm">
                        Reset Password
                      </button>
                      <button className="px-4 py-2 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500/20 transition-colors text-sm">
                        Delete Account
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Appearance */}
          {activeTab === 'appearance' && (
            <div className="glass-card p-6">
              <h3 className="text-lg font-semibold text-white mb-6">Appearance</h3>
              
              <div className="space-y-6">
                <div>
                  <p className="text-white mb-3">Theme</p>
                  <div className="grid grid-cols-3 gap-3">
                    <button className="p-4 bg-[#0A0A0A] border-2 border-apeiron-cyan rounded-lg text-center">
                      <Moon className="w-6 h-6 text-apeiron-cyan mx-auto mb-2" />
                      <span className="text-sm text-white">Dark</span>
                    </button>
                    <button className="p-4 bg-white border-2 border-transparent rounded-lg text-center opacity-50 cursor-not-allowed">
                      <div className="w-6 h-6 bg-gray-400 rounded-full mx-auto mb-2" />
                      <span className="text-sm text-gray-600">Light</span>
                    </button>
                    <button className="p-4 bg-gradient-to-br from-[#0A0A0A] to-[#1a1a1a] border-2 border-transparent hover:border-white/20 rounded-lg text-center">
                      <div className="w-6 h-6 bg-gradient-to-br from-apeiron-cyan to-apeiron-cyan-dark rounded-full mx-auto mb-2" />
                      <span className="text-sm text-white">Auto</span>
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between py-3 border-t border-white/5">
                  <div>
                    <p className="text-white">Compact Mode</p>
                    <p className="text-sm text-apeiron-gray">Reduce spacing for denser layout</p>
                  </div>
                  <div className="w-12 h-6 bg-white/20 rounded-full relative cursor-pointer">
                    <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full" />
                  </div>
                </div>

                <div className="flex items-center justify-between py-3">
                  <div>
                    <p className="text-white">Animations</p>
                    <p className="text-sm text-apeiron-gray">Enable smooth transitions</p>
                  </div>
                  <div className="w-12 h-6 bg-apeiron-cyan rounded-full relative cursor-pointer">
                    <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full" />
                  </div>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
