import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Users, Activity, TrendingUp, Server, Search, Filter,
  MoreVertical, Ban, Mail, ArrowUpRight,
  ArrowDownRight, Cpu, Wifi
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';
import { mockAdminAnalytics, monthlyGrowthData } from '@/lib/mockData';

const userStats = [
  { label: 'Total Users', value: mockAdminAnalytics.totalUsers, change: '+12%', trend: 'up' },
  { label: 'Active Users', value: mockAdminAnalytics.activeUsers, change: '+8%', trend: 'up' },
  { label: 'Queries Today', value: mockAdminAnalytics.queriesToday, change: '+24%', trend: 'up' },
  { label: 'New This Week', value: mockAdminAnalytics.newUsersThisWeek, change: '+15%', trend: 'up' },
];

const planDistribution = [
  { name: 'Starter', value: 850, color: '#7d7f83' },
  { name: 'Researcher', value: 398, color: '#2ab4d9' },
];

const recentUsers = [
  { id: '1', name: 'Dr. Sarah Chen', email: 'sarah.chen@mit.edu', plan: 'researcher', status: 'active', joined: '2 hours ago' },
  { id: '2', name: 'Prof. James Wilson', email: 'j.wilson@stanford.edu', plan: 'researcher', status: 'active', joined: '5 hours ago' },
  { id: '3', name: 'Maria Garcia', email: 'm.garcia@ox.ac.uk', plan: 'starter', status: 'active', joined: '1 day ago' },
  { id: '4', name: 'Dr. Ahmed Hassan', email: 'ahassan@ethz.ch', plan: 'researcher', status: 'inactive', joined: '2 days ago' },
  { id: '5', name: 'Lisa Park', email: 'lisa.park@cam.ac.uk', plan: 'starter', status: 'active', joined: '3 days ago' },
];

export default function AdminDashboard() {
  const [searchQuery, setSearchQuery] = useState('');

  const systemHealth = mockAdminAnalytics.systemHealth;

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-6"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">Admin Dashboard</h2>
            <p className="text-apeiron-gray">
              Monitor platform usage, manage users, and view system health.
            </p>
          </div>
          <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
            systemHealth.status === 'healthy' ? 'bg-green-500/10 text-green-400' :
            systemHealth.status === 'degraded' ? 'bg-yellow-500/10 text-yellow-400' :
            'bg-red-500/10 text-red-400'
          }`}>
            <div className={`w-2 h-2 rounded-full animate-pulse ${
              systemHealth.status === 'healthy' ? 'bg-green-400' :
              systemHealth.status === 'degraded' ? 'bg-yellow-400' :
              'bg-red-400'
            }`} />
            <span className="text-sm font-medium capitalize">{systemHealth.status}</span>
          </div>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {userStats.map((stat, index) => (
          <div key={stat.label} className="glass-card-hover p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 rounded-lg bg-apeiron-cyan/10 flex items-center justify-center">
                {index === 0 ? <Users className="w-5 h-5 text-apeiron-cyan" /> :
                 index === 1 ? <Activity className="w-5 h-5 text-apeiron-cyan" /> :
                 index === 2 ? <TrendingUp className="w-5 h-5 text-apeiron-cyan" /> :
                 <TrendingUp className="w-5 h-5 text-apeiron-cyan" />}
              </div>
              <div className={`flex items-center gap-1 text-sm ${
                stat.trend === 'up' ? 'text-green-400' : 'text-red-400'
              }`}>
                {stat.trend === 'up' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                {stat.change}
              </div>
            </div>
            <p className="text-3xl font-bold text-white mb-1">{stat.value.toLocaleString()}</p>
            <p className="text-sm text-apeiron-gray">{stat.label}</p>
          </div>
        ))}
      </motion.div>

      {/* System Health */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="glass-card p-6"
      >
        <h3 className="text-lg font-semibold text-white mb-6">System Health</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-green-500/10 flex items-center justify-center">
              <Server className="w-6 h-6 text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{systemHealth.uptime}%</p>
              <p className="text-sm text-apeiron-gray">Uptime</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-apeiron-cyan/10 flex items-center justify-center">
              <Wifi className="w-6 h-6 text-apeiron-cyan" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{systemHealth.latency}ms</p>
              <p className="text-sm text-apeiron-gray">Avg Latency</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center">
              <Cpu className="w-6 h-6 text-purple-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">42%</p>
              <p className="text-sm text-apeiron-gray">CPU Usage</p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Growth Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-card p-6"
        >
          <h3 className="text-lg font-semibold text-white mb-6">User Growth</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyGrowthData}>
                <defs>
                  <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2ab4d9" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#2ab4d9" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" />
                <XAxis dataKey="month" stroke="#7d7f83" fontSize={12} />
                <YAxis stroke="#7d7f83" fontSize={12} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#0A0A0A', 
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '8px'
                  }}
                />
                <Area 
                  type="monotone" 
                  dataKey="users" 
                  stroke="#2ab4d9" 
                  fillOpacity={1} 
                  fill="url(#colorUsers)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Plan Distribution */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="glass-card p-6"
        >
          <h3 className="text-lg font-semibold text-white mb-6">Plan Distribution</h3>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={planDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {planDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#0A0A0A', 
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '8px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 space-y-2">
            {planDistribution.map((plan) => (
              <div key={plan.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: plan.color }} />
                  <span className="text-sm text-apeiron-gray">{plan.name}</span>
                </div>
                <span className="text-sm text-white">{plan.value} users</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Recent Users */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="glass-card p-6"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <h3 className="text-lg font-semibold text-white">Recent Users</h3>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-apeiron-gray" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search users..."
                className="input-field pl-10 py-2 text-sm"
              />
            </div>
            <button className="p-2 bg-white/5 text-apeiron-gray rounded-lg hover:bg-white/10 transition-colors">
              <Filter className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/5">
                <th className="text-left py-3 px-4 text-sm font-medium text-apeiron-gray">User</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-apeiron-gray">Plan</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-apeiron-gray">Status</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-apeiron-gray">Joined</th>
                <th className="text-right py-3 px-4 text-sm font-medium text-apeiron-gray">Actions</th>
              </tr>
            </thead>
            <tbody>
              {recentUsers.map((user) => (
                <tr key={user.id} className="border-b border-white/5 last:border-0 hover:bg-white/5 transition-colors">
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-gradient-to-br from-apeiron-cyan to-apeiron-cyan-dark flex items-center justify-center">
                        <span className="text-black font-medium text-sm">
                          {user.name.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <p className="text-white font-medium">{user.name}</p>
                        <p className="text-sm text-apeiron-gray">{user.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <span className={`px-2 py-1 text-xs rounded-full capitalize ${
                      user.plan === 'researcher' 
                        ? 'bg-apeiron-cyan/10 text-apeiron-cyan' 
                        : 'bg-white/10 text-apeiron-gray'
                    }`}>
                      {user.plan}
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <span className={`flex items-center gap-1.5 text-sm ${
                      user.status === 'active' ? 'text-green-400' : 'text-apeiron-gray'
                    }`}>
                      <div className={`w-2 h-2 rounded-full ${
                        user.status === 'active' ? 'bg-green-400' : 'bg-apeiron-gray'
                      }`} />
                      {user.status}
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-sm text-apeiron-gray">{user.joined}</span>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center justify-end gap-2">
                      <button className="p-2 text-apeiron-gray hover:text-white transition-colors">
                        <Mail className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-apeiron-gray hover:text-white transition-colors">
                        <Ban className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-apeiron-gray hover:text-white transition-colors">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-4 text-center">
          <button className="text-sm text-apeiron-cyan hover:text-apeiron-cyan-light transition-colors">
            View all users
          </button>
        </div>
      </motion.div>
    </div>
  );
}
