import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Mail, Lock, User, ArrowRight, Loader2, 
  Chrome, Briefcase, Eye, EyeOff 
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

interface AuthPageProps {
  view: string;
  onViewChange: (view: string) => void;
}

export default function AuthPage({ view, onViewChange }: AuthPageProps) {
  const { login, signup, loginWithGoogle, loginWithMicrosoft, forgotPassword, isLoading } = useAuth();
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      if (view === 'login') {
        await login(formData.email, formData.password);
      } else if (view === 'signup') {
        await signup(formData.email, formData.password, formData.name);
      } else if (view === 'forgot-password') {
        await forgotPassword(formData.email);
        onViewChange('login');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  const handleSocialLogin = async (provider: 'google' | 'microsoft') => {
    try {
      if (provider === 'google') {
        await loginWithGoogle();
      } else {
        await loginWithMicrosoft();
      }
    } catch (err) {
      setError('Social login failed');
    }
  };

  const isLogin = view === 'login';
  const isSignup = view === 'signup';
  const isForgot = view === 'forgot-password';

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      {/* Background effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-apeiron-cyan/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-apeiron-cyan-dark/10 rounded-full blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
            className="inline-block"
          >
            <img src="/logo.png" alt="ApeironAI" className="w-16 h-16 mx-auto mb-4" />
          </motion.div>
          <h1 className="text-2xl font-bold text-white mb-2">
            {isLogin && 'Welcome back'}
            {isSignup && 'Create your account'}
            {isForgot && 'Reset your password'}
          </h1>
          <p className="text-apeiron-gray text-sm">
            {isLogin && 'Sign in to continue your research journey'}
            {isSignup && 'Start accelerating your scientific discovery'}
            {isForgot && 'Enter your email to receive reset instructions'}
          </p>
        </div>

        {/* Auth Card */}
        <div className="glass-card p-8">
          {/* Social Login Buttons */}
          {!isForgot && (
            <div className="space-y-3 mb-6">
              <button
                onClick={() => handleSocialLogin('google')}
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg px-4 py-3 text-white transition-colors disabled:opacity-50"
              >
                <Chrome className="w-5 h-5" />
                Continue with Google
              </button>
              <button
                onClick={() => handleSocialLogin('microsoft')}
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg px-4 py-3 text-white transition-colors disabled:opacity-50"
              >
                <Briefcase className="w-5 h-5" />
                Continue with Microsoft
              </button>
            </div>
          )}

          {/* Divider */}
          {!isForgot && (
            <div className="relative mb-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-white/10" />
              </div>
              <div className="relative flex justify-center">
                <span className="bg-[#0A0A0A] px-4 text-xs text-apeiron-gray uppercase">or</span>
              </div>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <AnimatePresence mode="wait">
              {isSignup && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                >
                  <label className="block text-sm text-apeiron-gray mb-2">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-apeiron-gray" />
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="input-field w-full pl-12"
                      placeholder="Enter your name"
                      required
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div>
              <label className="block text-sm text-apeiron-gray mb-2">Email</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-apeiron-gray" />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="input-field w-full pl-12"
                  placeholder="Enter your email"
                  required
                />
              </div>
            </div>

            {!isForgot && (
              <div>
                <label className="block text-sm text-apeiron-gray mb-2">Password</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-apeiron-gray" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="input-field w-full pl-12 pr-12"
                    placeholder="Enter your password"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-apeiron-gray hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            )}

            {isLogin && (
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => onViewChange('forgot-password')}
                  className="text-sm text-apeiron-cyan hover:text-apeiron-cyan-light transition-colors"
                >
                  Forgot password?
                </button>
              </div>
            )}

            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm"
              >
                {error}
              </motion.div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="btn-glow w-full flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  {isLogin && 'Sign In'}
                  {isSignup && 'Create Account'}
                  {isForgot && 'Send Reset Link'}
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Footer links */}
          <div className="mt-6 text-center">
            <p className="text-apeiron-gray text-sm">
              {isLogin && (
                <>
                  Don't have an account?{' '}
                  <button
                    onClick={() => onViewChange('signup')}
                    className="text-apeiron-cyan hover:text-apeiron-cyan-light transition-colors"
                  >
                    Sign up
                  </button>
                </>
              )}
              {isSignup && (
                <>
                  Already have an account?{' '}
                  <button
                    onClick={() => onViewChange('login')}
                    className="text-apeiron-cyan hover:text-apeiron-cyan-light transition-colors"
                  >
                    Sign in
                  </button>
                </>
              )}
              {isForgot && (
                <button
                  onClick={() => onViewChange('login')}
                  className="text-apeiron-cyan hover:text-apeiron-cyan-light transition-colors"
                >
                  Back to sign in
                </button>
              )}
            </p>
          </div>

          {/* Demo credentials hint */}
          {isLogin && (
            <div className="mt-6 pt-6 border-t border-white/10">
              <p className="text-xs text-apeiron-gray text-center">
                Demo: Use <span className="text-apeiron-cyan">demo@apeiron.ai</span> / <span className="text-apeiron-cyan">password</span>
              </p>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
