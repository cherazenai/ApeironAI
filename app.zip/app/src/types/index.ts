// User types
export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  role: 'user' | 'admin';
  plan: 'starter' | 'researcher';
  createdAt: Date;
}

// Auth types
export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

// Research query types
export interface ResearchQuery {
  id: string;
  userId: string;
  query: string;
  response: string;
  timestamp: Date;
  category?: string;
}

// Hypothesis types
export interface Hypothesis {
  id: string;
  userId: string;
  topic: string;
  hypothesis: string;
  confidenceScore: number;
  supportingPapers: Paper[];
  generatedAt: Date;
}

// Paper types
export interface Paper {
  id: string;
  userId: string;
  title: string;
  authors: string[];
  abstract: string;
  summary?: string;
  tags: string[];
  uploadedAt: Date;
  fileUrl?: string;
}

// Simulation types
export interface Simulation {
  id: string;
  userId: string;
  name: string;
  type: 'material' | 'reaction' | 'experiment';
  parameters: Record<string, any>;
  results?: Record<string, any>;
  status: 'pending' | 'running' | 'completed' | 'failed';
  createdAt: Date;
  completedAt?: Date;
}

// Experiment types
export interface Experiment {
  id: string;
  userId: string;
  hypothesisId?: string;
  title: string;
  description: string;
  steps: ExperimentStep[];
  status: 'planned' | 'in-progress' | 'completed';
  createdAt: Date;
}

export interface ExperimentStep {
  id: string;
  order: number;
  description: string;
  completed: boolean;
}

// Project types
export interface Project {
  id: string;
  userId: string;
  name: string;
  description: string;
  hypotheses: string[];
  papers: string[];
  simulations: string[];
  experiments: string[];
  createdAt: Date;
  updatedAt: Date;
}

// Dashboard analytics
export interface DashboardAnalytics {
  totalQueries: number;
  totalHypotheses: number;
  totalPapers: number;
  totalSimulations: number;
  queriesThisWeek: number;
  hypothesesThisWeek: number;
}

// Navigation item
export interface NavItem {
  id: string;
  label: string;
  icon: string;
  href: string;
  badge?: number;
}

// Pricing plan
export interface PricingPlan {
  id: string;
  name: string;
  price: number;
  period: string;
  description: string;
  features: string[];
  highlighted?: boolean;
  cta: string;
}

// Feature card
export interface Feature {
  id: string;
  title: string;
  description: string;
  icon: string;
}

// Use case
export interface UseCase {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
}

// Chat message
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  attachments?: Attachment[];
}

export interface Attachment {
  id: string;
  type: 'paper' | 'hypothesis' | 'simulation';
  title: string;
  content: string;
}

// Admin analytics
export interface AdminAnalytics {
  totalUsers: number;
  activeUsers: number;
  totalQueries: number;
  totalHypotheses: number;
  queriesToday: number;
  newUsersThisWeek: number;
  systemHealth: {
    status: 'healthy' | 'degraded' | 'down';
    uptime: number;
    latency: number;
  };
}
